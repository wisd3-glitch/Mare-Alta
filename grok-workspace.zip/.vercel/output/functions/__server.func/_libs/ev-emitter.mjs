import { t as __commonJSMin } from "../_runtime.mjs";
//#region node_modules/ev-emitter/ev-emitter.js
var require_ev_emitter = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	/**
	* EvEmitter v1.1.0
	* Lil' event emitter
	* MIT License
	*/
	(function(global, factory) {
		if (typeof define == "function" && define.amd) define(factory);
		else if (typeof module == "object" && module.exports) module.exports = factory();
		else global.EvEmitter = factory();
	})(typeof window != "undefined" ? window : exports, function() {
		"use strict";
		function EvEmitter() {}
		var proto = EvEmitter.prototype;
		proto.on = function(eventName, listener) {
			if (!eventName || !listener) return;
			var events = this._events = this._events || {};
			var listeners = events[eventName] = events[eventName] || [];
			if (listeners.indexOf(listener) == -1) listeners.push(listener);
			return this;
		};
		proto.once = function(eventName, listener) {
			if (!eventName || !listener) return;
			this.on(eventName, listener);
			var onceEvents = this._onceEvents = this._onceEvents || {};
			var onceListeners = onceEvents[eventName] = onceEvents[eventName] || {};
			onceListeners[listener] = true;
			return this;
		};
		proto.off = function(eventName, listener) {
			var listeners = this._events && this._events[eventName];
			if (!listeners || !listeners.length) return;
			var index = listeners.indexOf(listener);
			if (index != -1) listeners.splice(index, 1);
			return this;
		};
		proto.emitEvent = function(eventName, args) {
			var listeners = this._events && this._events[eventName];
			if (!listeners || !listeners.length) return;
			listeners = listeners.slice(0);
			args = args || [];
			var onceListeners = this._onceEvents && this._onceEvents[eventName];
			for (var i = 0; i < listeners.length; i++) {
				var listener = listeners[i];
				if (onceListeners && onceListeners[listener]) {
					this.off(eventName, listener);
					delete onceListeners[listener];
				}
				listener.apply(this, args);
			}
			return this;
		};
		proto.allOff = function() {
			delete this._events;
			delete this._onceEvents;
		};
		return EvEmitter;
	});
}));
//#endregion
export { require_ev_emitter as t };
