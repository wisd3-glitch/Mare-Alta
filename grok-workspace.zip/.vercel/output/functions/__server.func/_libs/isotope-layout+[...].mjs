import { t as __commonJSMin } from "../_runtime.mjs";
import { t as require_ev_emitter } from "./ev-emitter.mjs";
import { t as require_get_size } from "./get-size.mjs";
import { t as require_matches_selector } from "./desandro-matches-selector.mjs";
import { t as require_utils } from "./fizzy-ui-utils.mjs";
//#region node_modules/outlayer/item.js
var require_item$1 = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	/**
	* Outlayer Item
	*/
	(function(window, factory) {
		if (typeof define == "function" && define.amd) define(["ev-emitter/ev-emitter", "get-size/get-size"], factory);
		else if (typeof module == "object" && module.exports) module.exports = factory(require_ev_emitter(), require_get_size());
		else {
			window.Outlayer = {};
			window.Outlayer.Item = factory(window.EvEmitter, window.getSize);
		}
	})(window, function factory(EvEmitter, getSize) {
		"use strict";
		function isEmptyObj(obj) {
			for (var prop in obj) return false;
			return true;
		}
		var docElemStyle = document.documentElement.style;
		var transitionProperty = typeof docElemStyle.transition == "string" ? "transition" : "WebkitTransition";
		var transformProperty = typeof docElemStyle.transform == "string" ? "transform" : "WebkitTransform";
		var transitionEndEvent = {
			WebkitTransition: "webkitTransitionEnd",
			transition: "transitionend"
		}[transitionProperty];
		var vendorProperties = {
			transform: transformProperty,
			transition: transitionProperty,
			transitionDuration: transitionProperty + "Duration",
			transitionProperty: transitionProperty + "Property",
			transitionDelay: transitionProperty + "Delay"
		};
		function Item(element, layout) {
			if (!element) return;
			this.element = element;
			this.layout = layout;
			this.position = {
				x: 0,
				y: 0
			};
			this._create();
		}
		var proto = Item.prototype = Object.create(EvEmitter.prototype);
		proto.constructor = Item;
		proto._create = function() {
			this._transn = {
				ingProperties: {},
				clean: {},
				onEnd: {}
			};
			this.css({ position: "absolute" });
		};
		proto.handleEvent = function(event) {
			var method = "on" + event.type;
			if (this[method]) this[method](event);
		};
		proto.getSize = function() {
			this.size = getSize(this.element);
		};
		/**
		* apply CSS styles to element
		* @param {Object} style
		*/
		proto.css = function(style) {
			var elemStyle = this.element.style;
			for (var prop in style) {
				var supportedProp = vendorProperties[prop] || prop;
				elemStyle[supportedProp] = style[prop];
			}
		};
		proto.getPosition = function() {
			var style = getComputedStyle(this.element);
			var isOriginLeft = this.layout._getOption("originLeft");
			var isOriginTop = this.layout._getOption("originTop");
			var xValue = style[isOriginLeft ? "left" : "right"];
			var yValue = style[isOriginTop ? "top" : "bottom"];
			var x = parseFloat(xValue);
			var y = parseFloat(yValue);
			var layoutSize = this.layout.size;
			if (xValue.indexOf("%") != -1) x = x / 100 * layoutSize.width;
			if (yValue.indexOf("%") != -1) y = y / 100 * layoutSize.height;
			x = isNaN(x) ? 0 : x;
			y = isNaN(y) ? 0 : y;
			x -= isOriginLeft ? layoutSize.paddingLeft : layoutSize.paddingRight;
			y -= isOriginTop ? layoutSize.paddingTop : layoutSize.paddingBottom;
			this.position.x = x;
			this.position.y = y;
		};
		proto.layoutPosition = function() {
			var layoutSize = this.layout.size;
			var style = {};
			var isOriginLeft = this.layout._getOption("originLeft");
			var isOriginTop = this.layout._getOption("originTop");
			var xPadding = isOriginLeft ? "paddingLeft" : "paddingRight";
			var xProperty = isOriginLeft ? "left" : "right";
			var xResetProperty = isOriginLeft ? "right" : "left";
			var x = this.position.x + layoutSize[xPadding];
			style[xProperty] = this.getXValue(x);
			style[xResetProperty] = "";
			var yPadding = isOriginTop ? "paddingTop" : "paddingBottom";
			var yProperty = isOriginTop ? "top" : "bottom";
			var yResetProperty = isOriginTop ? "bottom" : "top";
			var y = this.position.y + layoutSize[yPadding];
			style[yProperty] = this.getYValue(y);
			style[yResetProperty] = "";
			this.css(style);
			this.emitEvent("layout", [this]);
		};
		proto.getXValue = function(x) {
			var isHorizontal = this.layout._getOption("horizontal");
			return this.layout.options.percentPosition && !isHorizontal ? x / this.layout.size.width * 100 + "%" : x + "px";
		};
		proto.getYValue = function(y) {
			var isHorizontal = this.layout._getOption("horizontal");
			return this.layout.options.percentPosition && isHorizontal ? y / this.layout.size.height * 100 + "%" : y + "px";
		};
		proto._transitionTo = function(x, y) {
			this.getPosition();
			var curX = this.position.x;
			var curY = this.position.y;
			var didNotMove = x == this.position.x && y == this.position.y;
			this.setPosition(x, y);
			if (didNotMove && !this.isTransitioning) {
				this.layoutPosition();
				return;
			}
			var transX = x - curX;
			var transY = y - curY;
			var transitionStyle = {};
			transitionStyle.transform = this.getTranslate(transX, transY);
			this.transition({
				to: transitionStyle,
				onTransitionEnd: { transform: this.layoutPosition },
				isCleaning: true
			});
		};
		proto.getTranslate = function(x, y) {
			var isOriginLeft = this.layout._getOption("originLeft");
			var isOriginTop = this.layout._getOption("originTop");
			x = isOriginLeft ? x : -x;
			y = isOriginTop ? y : -y;
			return "translate3d(" + x + "px, " + y + "px, 0)";
		};
		proto.goTo = function(x, y) {
			this.setPosition(x, y);
			this.layoutPosition();
		};
		proto.moveTo = proto._transitionTo;
		proto.setPosition = function(x, y) {
			this.position.x = parseFloat(x);
			this.position.y = parseFloat(y);
		};
		/**
		* @param {Object} style - CSS
		* @param {Function} onTransitionEnd
		*/
		proto._nonTransition = function(args) {
			this.css(args.to);
			if (args.isCleaning) this._removeStyles(args.to);
			for (var prop in args.onTransitionEnd) args.onTransitionEnd[prop].call(this);
		};
		/**
		* proper transition
		* @param {Object} args - arguments
		*   @param {Object} to - style to transition to
		*   @param {Object} from - style to start transition from
		*   @param {Boolean} isCleaning - removes transition styles after transition
		*   @param {Function} onTransitionEnd - callback
		*/
		proto.transition = function(args) {
			if (!parseFloat(this.layout.options.transitionDuration)) {
				this._nonTransition(args);
				return;
			}
			var _transition = this._transn;
			for (var prop in args.onTransitionEnd) _transition.onEnd[prop] = args.onTransitionEnd[prop];
			for (prop in args.to) {
				_transition.ingProperties[prop] = true;
				if (args.isCleaning) _transition.clean[prop] = true;
			}
			if (args.from) {
				this.css(args.from);
				this.element.offsetHeight;
			}
			this.enableTransition(args.to);
			this.css(args.to);
			this.isTransitioning = true;
		};
		function toDashedAll(str) {
			return str.replace(/([A-Z])/g, function($1) {
				return "-" + $1.toLowerCase();
			});
		}
		var transitionProps = "opacity," + toDashedAll(transformProperty);
		proto.enableTransition = function() {
			if (this.isTransitioning) return;
			var duration = this.layout.options.transitionDuration;
			duration = typeof duration == "number" ? duration + "ms" : duration;
			this.css({
				transitionProperty: transitionProps,
				transitionDuration: duration,
				transitionDelay: this.staggerDelay || 0
			});
			this.element.addEventListener(transitionEndEvent, this, false);
		};
		proto.onwebkitTransitionEnd = function(event) {
			this.ontransitionend(event);
		};
		proto.onotransitionend = function(event) {
			this.ontransitionend(event);
		};
		var dashedVendorProperties = { "-webkit-transform": "transform" };
		proto.ontransitionend = function(event) {
			if (event.target !== this.element) return;
			var _transition = this._transn;
			var propertyName = dashedVendorProperties[event.propertyName] || event.propertyName;
			delete _transition.ingProperties[propertyName];
			if (isEmptyObj(_transition.ingProperties)) this.disableTransition();
			if (propertyName in _transition.clean) {
				this.element.style[event.propertyName] = "";
				delete _transition.clean[propertyName];
			}
			if (propertyName in _transition.onEnd) {
				_transition.onEnd[propertyName].call(this);
				delete _transition.onEnd[propertyName];
			}
			this.emitEvent("transitionEnd", [this]);
		};
		proto.disableTransition = function() {
			this.removeTransitionStyles();
			this.element.removeEventListener(transitionEndEvent, this, false);
			this.isTransitioning = false;
		};
		/**
		* removes style property from element
		* @param {Object} style
		**/
		proto._removeStyles = function(style) {
			var cleanStyle = {};
			for (var prop in style) cleanStyle[prop] = "";
			this.css(cleanStyle);
		};
		var cleanTransitionStyle = {
			transitionProperty: "",
			transitionDuration: "",
			transitionDelay: ""
		};
		proto.removeTransitionStyles = function() {
			this.css(cleanTransitionStyle);
		};
		proto.stagger = function(delay) {
			delay = isNaN(delay) ? 0 : delay;
			this.staggerDelay = delay + "ms";
		};
		proto.removeElem = function() {
			this.element.parentNode.removeChild(this.element);
			this.css({ display: "" });
			this.emitEvent("remove", [this]);
		};
		proto.remove = function() {
			if (!transitionProperty || !parseFloat(this.layout.options.transitionDuration)) {
				this.removeElem();
				return;
			}
			this.once("transitionEnd", function() {
				this.removeElem();
			});
			this.hide();
		};
		proto.reveal = function() {
			delete this.isHidden;
			this.css({ display: "" });
			var options = this.layout.options;
			var onTransitionEnd = {};
			var transitionEndProperty = this.getHideRevealTransitionEndProperty("visibleStyle");
			onTransitionEnd[transitionEndProperty] = this.onRevealTransitionEnd;
			this.transition({
				from: options.hiddenStyle,
				to: options.visibleStyle,
				isCleaning: true,
				onTransitionEnd
			});
		};
		proto.onRevealTransitionEnd = function() {
			if (!this.isHidden) this.emitEvent("reveal");
		};
		/**
		* get style property use for hide/reveal transition end
		* @param {String} styleProperty - hiddenStyle/visibleStyle
		* @returns {String}
		*/
		proto.getHideRevealTransitionEndProperty = function(styleProperty) {
			var optionStyle = this.layout.options[styleProperty];
			if (optionStyle.opacity) return "opacity";
			for (var prop in optionStyle) return prop;
		};
		proto.hide = function() {
			this.isHidden = true;
			this.css({ display: "" });
			var options = this.layout.options;
			var onTransitionEnd = {};
			var transitionEndProperty = this.getHideRevealTransitionEndProperty("hiddenStyle");
			onTransitionEnd[transitionEndProperty] = this.onHideTransitionEnd;
			this.transition({
				from: options.visibleStyle,
				to: options.hiddenStyle,
				isCleaning: true,
				onTransitionEnd
			});
		};
		proto.onHideTransitionEnd = function() {
			if (this.isHidden) {
				this.css({ display: "none" });
				this.emitEvent("hide");
			}
		};
		proto.destroy = function() {
			this.css({
				position: "",
				left: "",
				right: "",
				top: "",
				bottom: "",
				transition: "",
				transform: ""
			});
		};
		return Item;
	});
}));
//#endregion
//#region node_modules/outlayer/outlayer.js
var require_outlayer = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	/*!
	* Outlayer v2.1.1
	* the brains and guts of a layout library
	* MIT license
	*/
	(function(window, factory) {
		"use strict";
		if (typeof define == "function" && define.amd) define([
			"ev-emitter/ev-emitter",
			"get-size/get-size",
			"fizzy-ui-utils/utils",
			"./item"
		], function(EvEmitter, getSize, utils, Item) {
			return factory(window, EvEmitter, getSize, utils, Item);
		});
		else if (typeof module == "object" && module.exports) module.exports = factory(window, require_ev_emitter(), require_get_size(), require_utils(), require_item$1());
		else window.Outlayer = factory(window, window.EvEmitter, window.getSize, window.fizzyUIUtils, window.Outlayer.Item);
	})(window, function factory(window, EvEmitter, getSize, utils, Item) {
		"use strict";
		var console = window.console;
		var jQuery = window.jQuery;
		var noop = function() {};
		var GUID = 0;
		var instances = {};
		/**
		* @param {Element, String} element
		* @param {Object} options
		* @constructor
		*/
		function Outlayer(element, options) {
			var queryElement = utils.getQueryElement(element);
			if (!queryElement) {
				if (console) console.error("Bad element for " + this.constructor.namespace + ": " + (queryElement || element));
				return;
			}
			this.element = queryElement;
			if (jQuery) this.$element = jQuery(this.element);
			this.options = utils.extend({}, this.constructor.defaults);
			this.option(options);
			var id = ++GUID;
			this.element.outlayerGUID = id;
			instances[id] = this;
			this._create();
			if (this._getOption("initLayout")) this.layout();
		}
		Outlayer.namespace = "outlayer";
		Outlayer.Item = Item;
		Outlayer.defaults = {
			containerStyle: { position: "relative" },
			initLayout: true,
			originLeft: true,
			originTop: true,
			resize: true,
			resizeContainer: true,
			transitionDuration: "0.4s",
			hiddenStyle: {
				opacity: 0,
				transform: "scale(0.001)"
			},
			visibleStyle: {
				opacity: 1,
				transform: "scale(1)"
			}
		};
		var proto = Outlayer.prototype;
		utils.extend(proto, EvEmitter.prototype);
		/**
		* set options
		* @param {Object} opts
		*/
		proto.option = function(opts) {
			utils.extend(this.options, opts);
		};
		/**
		* get backwards compatible option value, check old name
		*/
		proto._getOption = function(option) {
			var oldOption = this.constructor.compatOptions[option];
			return oldOption && this.options[oldOption] !== void 0 ? this.options[oldOption] : this.options[option];
		};
		Outlayer.compatOptions = {
			initLayout: "isInitLayout",
			horizontal: "isHorizontal",
			layoutInstant: "isLayoutInstant",
			originLeft: "isOriginLeft",
			originTop: "isOriginTop",
			resize: "isResizeBound",
			resizeContainer: "isResizingContainer"
		};
		proto._create = function() {
			this.reloadItems();
			this.stamps = [];
			this.stamp(this.options.stamp);
			utils.extend(this.element.style, this.options.containerStyle);
			if (this._getOption("resize")) this.bindResize();
		};
		proto.reloadItems = function() {
			this.items = this._itemize(this.element.children);
		};
		/**
		* turn elements into Outlayer.Items to be used in layout
		* @param {Array or NodeList or HTMLElement} elems
		* @returns {Array} items - collection of new Outlayer Items
		*/
		proto._itemize = function(elems) {
			var itemElems = this._filterFindItemElements(elems);
			var Item = this.constructor.Item;
			var items = [];
			for (var i = 0; i < itemElems.length; i++) {
				var elem = itemElems[i];
				var item = new Item(elem, this);
				items.push(item);
			}
			return items;
		};
		/**
		* get item elements to be used in layout
		* @param {Array or NodeList or HTMLElement} elems
		* @returns {Array} items - item elements
		*/
		proto._filterFindItemElements = function(elems) {
			return utils.filterFindElements(elems, this.options.itemSelector);
		};
		/**
		* getter method for getting item elements
		* @returns {Array} elems - collection of item elements
		*/
		proto.getItemElements = function() {
			return this.items.map(function(item) {
				return item.element;
			});
		};
		/**
		* lays out all items
		*/
		proto.layout = function() {
			this._resetLayout();
			this._manageStamps();
			var layoutInstant = this._getOption("layoutInstant");
			var isInstant = layoutInstant !== void 0 ? layoutInstant : !this._isLayoutInited;
			this.layoutItems(this.items, isInstant);
			this._isLayoutInited = true;
		};
		proto._init = proto.layout;
		/**
		* logic before any new layout
		*/
		proto._resetLayout = function() {
			this.getSize();
		};
		proto.getSize = function() {
			this.size = getSize(this.element);
		};
		/**
		* get measurement from option, for columnWidth, rowHeight, gutter
		* if option is String -> get element from selector string, & get size of element
		* if option is Element -> get size of element
		* else use option as a number
		*
		* @param {String} measurement
		* @param {String} size - width or height
		* @private
		*/
		proto._getMeasurement = function(measurement, size) {
			var option = this.options[measurement];
			var elem;
			if (!option) this[measurement] = 0;
			else {
				if (typeof option == "string") elem = this.element.querySelector(option);
				else if (option instanceof HTMLElement) elem = option;
				this[measurement] = elem ? getSize(elem)[size] : option;
			}
		};
		/**
		* layout a collection of item elements
		* @api public
		*/
		proto.layoutItems = function(items, isInstant) {
			items = this._getItemsForLayout(items);
			this._layoutItems(items, isInstant);
			this._postLayout();
		};
		/**
		* get the items to be laid out
		* you may want to skip over some items
		* @param {Array} items
		* @returns {Array} items
		*/
		proto._getItemsForLayout = function(items) {
			return items.filter(function(item) {
				return !item.isIgnored;
			});
		};
		/**
		* layout items
		* @param {Array} items
		* @param {Boolean} isInstant
		*/
		proto._layoutItems = function(items, isInstant) {
			this._emitCompleteOnItems("layout", items);
			if (!items || !items.length) return;
			var queue = [];
			items.forEach(function(item) {
				var position = this._getItemLayoutPosition(item);
				position.item = item;
				position.isInstant = isInstant || item.isLayoutInstant;
				queue.push(position);
			}, this);
			this._processLayoutQueue(queue);
		};
		/**
		* get item layout position
		* @param {Outlayer.Item} item
		* @returns {Object} x and y position
		*/
		proto._getItemLayoutPosition = function() {
			return {
				x: 0,
				y: 0
			};
		};
		/**
		* iterate over array and position each item
		* Reason being - separating this logic prevents 'layout invalidation'
		* thx @paul_irish
		* @param {Array} queue
		*/
		proto._processLayoutQueue = function(queue) {
			this.updateStagger();
			queue.forEach(function(obj, i) {
				this._positionItem(obj.item, obj.x, obj.y, obj.isInstant, i);
			}, this);
		};
		proto.updateStagger = function() {
			var stagger = this.options.stagger;
			if (stagger === null || stagger === void 0) {
				this.stagger = 0;
				return;
			}
			this.stagger = getMilliseconds(stagger);
			return this.stagger;
		};
		/**
		* Sets position of item in DOM
		* @param {Outlayer.Item} item
		* @param {Number} x - horizontal position
		* @param {Number} y - vertical position
		* @param {Boolean} isInstant - disables transitions
		*/
		proto._positionItem = function(item, x, y, isInstant, i) {
			if (isInstant) item.goTo(x, y);
			else {
				item.stagger(i * this.stagger);
				item.moveTo(x, y);
			}
		};
		/**
		* Any logic you want to do after each layout,
		* i.e. size the container
		*/
		proto._postLayout = function() {
			this.resizeContainer();
		};
		proto.resizeContainer = function() {
			if (!this._getOption("resizeContainer")) return;
			var size = this._getContainerSize();
			if (size) {
				this._setContainerMeasure(size.width, true);
				this._setContainerMeasure(size.height, false);
			}
		};
		/**
		* Sets width or height of container if returned
		* @returns {Object} size
		*   @param {Number} width
		*   @param {Number} height
		*/
		proto._getContainerSize = noop;
		/**
		* @param {Number} measure - size of width or height
		* @param {Boolean} isWidth
		*/
		proto._setContainerMeasure = function(measure, isWidth) {
			if (measure === void 0) return;
			var elemSize = this.size;
			if (elemSize.isBorderBox) measure += isWidth ? elemSize.paddingLeft + elemSize.paddingRight + elemSize.borderLeftWidth + elemSize.borderRightWidth : elemSize.paddingBottom + elemSize.paddingTop + elemSize.borderTopWidth + elemSize.borderBottomWidth;
			measure = Math.max(measure, 0);
			this.element.style[isWidth ? "width" : "height"] = measure + "px";
		};
		/**
		* emit eventComplete on a collection of items events
		* @param {String} eventName
		* @param {Array} items - Outlayer.Items
		*/
		proto._emitCompleteOnItems = function(eventName, items) {
			var _this = this;
			function onComplete() {
				_this.dispatchEvent(eventName + "Complete", null, [items]);
			}
			var count = items.length;
			if (!items || !count) {
				onComplete();
				return;
			}
			var doneCount = 0;
			function tick() {
				doneCount++;
				if (doneCount == count) onComplete();
			}
			items.forEach(function(item) {
				item.once(eventName, tick);
			});
		};
		/**
		* emits events via EvEmitter and jQuery events
		* @param {String} type - name of event
		* @param {Event} event - original event
		* @param {Array} args - extra arguments
		*/
		proto.dispatchEvent = function(type, event, args) {
			var emitArgs = event ? [event].concat(args) : args;
			this.emitEvent(type, emitArgs);
			if (jQuery) {
				this.$element = this.$element || jQuery(this.element);
				if (event) {
					var $event = jQuery.Event(event);
					$event.type = type;
					this.$element.trigger($event, args);
				} else this.$element.trigger(type, args);
			}
		};
		/**
		* keep item in collection, but do not lay it out
		* ignored items do not get skipped in layout
		* @param {Element} elem
		*/
		proto.ignore = function(elem) {
			var item = this.getItem(elem);
			if (item) item.isIgnored = true;
		};
		/**
		* return item to layout collection
		* @param {Element} elem
		*/
		proto.unignore = function(elem) {
			var item = this.getItem(elem);
			if (item) delete item.isIgnored;
		};
		/**
		* adds elements to stamps
		* @param {NodeList, Array, Element, or String} elems
		*/
		proto.stamp = function(elems) {
			elems = this._find(elems);
			if (!elems) return;
			this.stamps = this.stamps.concat(elems);
			elems.forEach(this.ignore, this);
		};
		/**
		* removes elements to stamps
		* @param {NodeList, Array, or Element} elems
		*/
		proto.unstamp = function(elems) {
			elems = this._find(elems);
			if (!elems) return;
			elems.forEach(function(elem) {
				utils.removeFrom(this.stamps, elem);
				this.unignore(elem);
			}, this);
		};
		/**
		* finds child elements
		* @param {NodeList, Array, Element, or String} elems
		* @returns {Array} elems
		*/
		proto._find = function(elems) {
			if (!elems) return;
			if (typeof elems == "string") elems = this.element.querySelectorAll(elems);
			elems = utils.makeArray(elems);
			return elems;
		};
		proto._manageStamps = function() {
			if (!this.stamps || !this.stamps.length) return;
			this._getBoundingRect();
			this.stamps.forEach(this._manageStamp, this);
		};
		proto._getBoundingRect = function() {
			var boundingRect = this.element.getBoundingClientRect();
			var size = this.size;
			this._boundingRect = {
				left: boundingRect.left + size.paddingLeft + size.borderLeftWidth,
				top: boundingRect.top + size.paddingTop + size.borderTopWidth,
				right: boundingRect.right - (size.paddingRight + size.borderRightWidth),
				bottom: boundingRect.bottom - (size.paddingBottom + size.borderBottomWidth)
			};
		};
		/**
		* @param {Element} stamp
		**/
		proto._manageStamp = noop;
		/**
		* get x/y position of element relative to container element
		* @param {Element} elem
		* @returns {Object} offset - has left, top, right, bottom
		*/
		proto._getElementOffset = function(elem) {
			var boundingRect = elem.getBoundingClientRect();
			var thisRect = this._boundingRect;
			var size = getSize(elem);
			return {
				left: boundingRect.left - thisRect.left - size.marginLeft,
				top: boundingRect.top - thisRect.top - size.marginTop,
				right: thisRect.right - boundingRect.right - size.marginRight,
				bottom: thisRect.bottom - boundingRect.bottom - size.marginBottom
			};
		};
		proto.handleEvent = utils.handleEvent;
		/**
		* Bind layout to window resizing
		*/
		proto.bindResize = function() {
			window.addEventListener("resize", this);
			this.isResizeBound = true;
		};
		/**
		* Unbind layout to window resizing
		*/
		proto.unbindResize = function() {
			window.removeEventListener("resize", this);
			this.isResizeBound = false;
		};
		proto.onresize = function() {
			this.resize();
		};
		utils.debounceMethod(Outlayer, "onresize", 100);
		proto.resize = function() {
			if (!this.isResizeBound || !this.needsResizeLayout()) return;
			this.layout();
		};
		/**
		* check if layout is needed post layout
		* @returns Boolean
		*/
		proto.needsResizeLayout = function() {
			var size = getSize(this.element);
			return this.size && size && size.innerWidth !== this.size.innerWidth;
		};
		/**
		* add items to Outlayer instance
		* @param {Array or NodeList or Element} elems
		* @returns {Array} items - Outlayer.Items
		**/
		proto.addItems = function(elems) {
			var items = this._itemize(elems);
			if (items.length) this.items = this.items.concat(items);
			return items;
		};
		/**
		* Layout newly-appended item elements
		* @param {Array or NodeList or Element} elems
		*/
		proto.appended = function(elems) {
			var items = this.addItems(elems);
			if (!items.length) return;
			this.layoutItems(items, true);
			this.reveal(items);
		};
		/**
		* Layout prepended elements
		* @param {Array or NodeList or Element} elems
		*/
		proto.prepended = function(elems) {
			var items = this._itemize(elems);
			if (!items.length) return;
			var previousItems = this.items.slice(0);
			this.items = items.concat(previousItems);
			this._resetLayout();
			this._manageStamps();
			this.layoutItems(items, true);
			this.reveal(items);
			this.layoutItems(previousItems);
		};
		/**
		* reveal a collection of items
		* @param {Array of Outlayer.Items} items
		*/
		proto.reveal = function(items) {
			this._emitCompleteOnItems("reveal", items);
			if (!items || !items.length) return;
			var stagger = this.updateStagger();
			items.forEach(function(item, i) {
				item.stagger(i * stagger);
				item.reveal();
			});
		};
		/**
		* hide a collection of items
		* @param {Array of Outlayer.Items} items
		*/
		proto.hide = function(items) {
			this._emitCompleteOnItems("hide", items);
			if (!items || !items.length) return;
			var stagger = this.updateStagger();
			items.forEach(function(item, i) {
				item.stagger(i * stagger);
				item.hide();
			});
		};
		/**
		* reveal item elements
		* @param {Array}, {Element}, {NodeList} items
		*/
		proto.revealItemElements = function(elems) {
			var items = this.getItems(elems);
			this.reveal(items);
		};
		/**
		* hide item elements
		* @param {Array}, {Element}, {NodeList} items
		*/
		proto.hideItemElements = function(elems) {
			var items = this.getItems(elems);
			this.hide(items);
		};
		/**
		* get Outlayer.Item, given an Element
		* @param {Element} elem
		* @param {Function} callback
		* @returns {Outlayer.Item} item
		*/
		proto.getItem = function(elem) {
			for (var i = 0; i < this.items.length; i++) {
				var item = this.items[i];
				if (item.element == elem) return item;
			}
		};
		/**
		* get collection of Outlayer.Items, given Elements
		* @param {Array} elems
		* @returns {Array} items - Outlayer.Items
		*/
		proto.getItems = function(elems) {
			elems = utils.makeArray(elems);
			var items = [];
			elems.forEach(function(elem) {
				var item = this.getItem(elem);
				if (item) items.push(item);
			}, this);
			return items;
		};
		/**
		* remove element(s) from instance and DOM
		* @param {Array or NodeList or Element} elems
		*/
		proto.remove = function(elems) {
			var removeItems = this.getItems(elems);
			this._emitCompleteOnItems("remove", removeItems);
			if (!removeItems || !removeItems.length) return;
			removeItems.forEach(function(item) {
				item.remove();
				utils.removeFrom(this.items, item);
			}, this);
		};
		proto.destroy = function() {
			var style = this.element.style;
			style.height = "";
			style.position = "";
			style.width = "";
			this.items.forEach(function(item) {
				item.destroy();
			});
			this.unbindResize();
			var id = this.element.outlayerGUID;
			delete instances[id];
			delete this.element.outlayerGUID;
			if (jQuery) jQuery.removeData(this.element, this.constructor.namespace);
		};
		/**
		* get Outlayer instance from element
		* @param {Element} elem
		* @returns {Outlayer}
		*/
		Outlayer.data = function(elem) {
			elem = utils.getQueryElement(elem);
			var id = elem && elem.outlayerGUID;
			return id && instances[id];
		};
		/**
		* create a layout class
		* @param {String} namespace
		*/
		Outlayer.create = function(namespace, options) {
			var Layout = subclass(Outlayer);
			Layout.defaults = utils.extend({}, Outlayer.defaults);
			utils.extend(Layout.defaults, options);
			Layout.compatOptions = utils.extend({}, Outlayer.compatOptions);
			Layout.namespace = namespace;
			Layout.data = Outlayer.data;
			Layout.Item = subclass(Item);
			utils.htmlInit(Layout, namespace);
			if (jQuery && jQuery.bridget) jQuery.bridget(namespace, Layout);
			return Layout;
		};
		function subclass(Parent) {
			function SubClass() {
				Parent.apply(this, arguments);
			}
			SubClass.prototype = Object.create(Parent.prototype);
			SubClass.prototype.constructor = SubClass;
			return SubClass;
		}
		var msUnits = {
			ms: 1,
			s: 1e3
		};
		function getMilliseconds(time) {
			if (typeof time == "number") return time;
			var matches = time.match(/(^\d*\.?\d*)(\w*)/);
			var num = matches && matches[1];
			var unit = matches && matches[2];
			if (!num.length) return 0;
			num = parseFloat(num);
			var mult = msUnits[unit] || 1;
			return num * mult;
		}
		Outlayer.Item = Item;
		return Outlayer;
	});
}));
//#endregion
//#region node_modules/isotope-layout/js/item.js
var require_item = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	/**
	* Isotope Item
	**/
	(function(window, factory) {
		if (typeof define == "function" && define.amd) define(["outlayer/outlayer"], factory);
		else if (typeof module == "object" && module.exports) module.exports = factory(require_outlayer());
		else {
			window.Isotope = window.Isotope || {};
			window.Isotope.Item = factory(window.Outlayer);
		}
	})(window, function factory(Outlayer) {
		"use strict";
		function Item() {
			Outlayer.Item.apply(this, arguments);
		}
		var proto = Item.prototype = Object.create(Outlayer.Item.prototype);
		var _create = proto._create;
		proto._create = function() {
			this.id = this.layout.itemGUID++;
			_create.call(this);
			this.sortData = {};
		};
		proto.updateSortData = function() {
			if (this.isIgnored) return;
			this.sortData.id = this.id;
			this.sortData["original-order"] = this.id;
			this.sortData.random = Math.random();
			var getSortData = this.layout.options.getSortData;
			var sorters = this.layout._sorters;
			for (var key in getSortData) {
				var sorter = sorters[key];
				this.sortData[key] = sorter(this.element, this);
			}
		};
		var _destroy = proto.destroy;
		proto.destroy = function() {
			_destroy.apply(this, arguments);
			this.css({ display: "" });
		};
		return Item;
	});
}));
//#endregion
//#region node_modules/isotope-layout/js/layout-mode.js
var require_layout_mode = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	/**
	* Isotope LayoutMode
	*/
	(function(window, factory) {
		if (typeof define == "function" && define.amd) define(["get-size/get-size", "outlayer/outlayer"], factory);
		else if (typeof module == "object" && module.exports) module.exports = factory(require_get_size(), require_outlayer());
		else {
			window.Isotope = window.Isotope || {};
			window.Isotope.LayoutMode = factory(window.getSize, window.Outlayer);
		}
	})(window, function factory(getSize, Outlayer) {
		"use strict";
		function LayoutMode(isotope) {
			this.isotope = isotope;
			if (isotope) {
				this.options = isotope.options[this.namespace];
				this.element = isotope.element;
				this.items = isotope.filteredItems;
				this.size = isotope.size;
			}
		}
		var proto = LayoutMode.prototype;
		[
			"_resetLayout",
			"_getItemLayoutPosition",
			"_manageStamp",
			"_getContainerSize",
			"_getElementOffset",
			"needsResizeLayout",
			"_getOption"
		].forEach(function(methodName) {
			proto[methodName] = function() {
				return Outlayer.prototype[methodName].apply(this.isotope, arguments);
			};
		});
		proto.needsVerticalResizeLayout = function() {
			var size = getSize(this.isotope.element);
			return this.isotope.size && size && size.innerHeight != this.isotope.size.innerHeight;
		};
		proto._getMeasurement = function() {
			this.isotope._getMeasurement.apply(this, arguments);
		};
		proto.getColumnWidth = function() {
			this.getSegmentSize("column", "Width");
		};
		proto.getRowHeight = function() {
			this.getSegmentSize("row", "Height");
		};
		/**
		* get columnWidth or rowHeight
		* segment: 'column' or 'row'
		* size 'Width' or 'Height'
		**/
		proto.getSegmentSize = function(segment, size) {
			var segmentName = segment + size;
			var outerSize = "outer" + size;
			this._getMeasurement(segmentName, outerSize);
			if (this[segmentName]) return;
			var firstItemSize = this.getFirstItemSize();
			this[segmentName] = firstItemSize && firstItemSize[outerSize] || this.isotope.size["inner" + size];
		};
		proto.getFirstItemSize = function() {
			var firstItem = this.isotope.filteredItems[0];
			return firstItem && firstItem.element && getSize(firstItem.element);
		};
		proto.layout = function() {
			this.isotope.layout.apply(this.isotope, arguments);
		};
		proto.getSize = function() {
			this.isotope.getSize();
			this.size = this.isotope.size;
		};
		LayoutMode.modes = {};
		LayoutMode.create = function(namespace, options) {
			function Mode() {
				LayoutMode.apply(this, arguments);
			}
			Mode.prototype = Object.create(proto);
			Mode.prototype.constructor = Mode;
			if (options) Mode.options = options;
			Mode.prototype.namespace = namespace;
			LayoutMode.modes[namespace] = Mode;
			return Mode;
		};
		return LayoutMode;
	});
}));
//#endregion
//#region node_modules/masonry-layout/masonry.js
var require_masonry$1 = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	/*!
	* Masonry v4.2.2
	* Cascading grid layout library
	* https://masonry.desandro.com
	* MIT License
	* by David DeSandro
	*/
	(function(window, factory) {
		if (typeof define == "function" && define.amd) define(["outlayer/outlayer", "get-size/get-size"], factory);
		else if (typeof module == "object" && module.exports) module.exports = factory(require_outlayer(), require_get_size());
		else window.Masonry = factory(window.Outlayer, window.getSize);
	})(window, function factory(Outlayer, getSize) {
		"use strict";
		var Masonry = Outlayer.create("masonry");
		Masonry.compatOptions.fitWidth = "isFitWidth";
		var proto = Masonry.prototype;
		proto._resetLayout = function() {
			this.getSize();
			this._getMeasurement("columnWidth", "outerWidth");
			this._getMeasurement("gutter", "outerWidth");
			this.measureColumns();
			this.colYs = [];
			for (var i = 0; i < this.cols; i++) this.colYs.push(0);
			this.maxY = 0;
			this.horizontalColIndex = 0;
		};
		proto.measureColumns = function() {
			this.getContainerWidth();
			if (!this.columnWidth) {
				var firstItem = this.items[0];
				var firstItemElem = firstItem && firstItem.element;
				this.columnWidth = firstItemElem && getSize(firstItemElem).outerWidth || this.containerWidth;
			}
			var columnWidth = this.columnWidth += this.gutter;
			var containerWidth = this.containerWidth + this.gutter;
			var cols = containerWidth / columnWidth;
			var excess = columnWidth - containerWidth % columnWidth;
			cols = Math[excess && excess < 1 ? "round" : "floor"](cols);
			this.cols = Math.max(cols, 1);
		};
		proto.getContainerWidth = function() {
			var size = getSize(this._getOption("fitWidth") ? this.element.parentNode : this.element);
			this.containerWidth = size && size.innerWidth;
		};
		proto._getItemLayoutPosition = function(item) {
			item.getSize();
			var remainder = item.size.outerWidth % this.columnWidth;
			var colSpan = Math[remainder && remainder < 1 ? "round" : "ceil"](item.size.outerWidth / this.columnWidth);
			colSpan = Math.min(colSpan, this.cols);
			var colPosMethod = this.options.horizontalOrder ? "_getHorizontalColPosition" : "_getTopColPosition";
			var colPosition = this[colPosMethod](colSpan, item);
			var position = {
				x: this.columnWidth * colPosition.col,
				y: colPosition.y
			};
			var setHeight = colPosition.y + item.size.outerHeight;
			var setMax = colSpan + colPosition.col;
			for (var i = colPosition.col; i < setMax; i++) this.colYs[i] = setHeight;
			return position;
		};
		proto._getTopColPosition = function(colSpan) {
			var colGroup = this._getTopColGroup(colSpan);
			var minimumY = Math.min.apply(Math, colGroup);
			return {
				col: colGroup.indexOf(minimumY),
				y: minimumY
			};
		};
		/**
		* @param {Number} colSpan - number of columns the element spans
		* @returns {Array} colGroup
		*/
		proto._getTopColGroup = function(colSpan) {
			if (colSpan < 2) return this.colYs;
			var colGroup = [];
			var groupCount = this.cols + 1 - colSpan;
			for (var i = 0; i < groupCount; i++) colGroup[i] = this._getColGroupY(i, colSpan);
			return colGroup;
		};
		proto._getColGroupY = function(col, colSpan) {
			if (colSpan < 2) return this.colYs[col];
			var groupColYs = this.colYs.slice(col, col + colSpan);
			return Math.max.apply(Math, groupColYs);
		};
		proto._getHorizontalColPosition = function(colSpan, item) {
			var col = this.horizontalColIndex % this.cols;
			col = colSpan > 1 && col + colSpan > this.cols ? 0 : col;
			var hasSize = item.size.outerWidth && item.size.outerHeight;
			this.horizontalColIndex = hasSize ? col + colSpan : this.horizontalColIndex;
			return {
				col,
				y: this._getColGroupY(col, colSpan)
			};
		};
		proto._manageStamp = function(stamp) {
			var stampSize = getSize(stamp);
			var offset = this._getElementOffset(stamp);
			var firstX = this._getOption("originLeft") ? offset.left : offset.right;
			var lastX = firstX + stampSize.outerWidth;
			var firstCol = Math.floor(firstX / this.columnWidth);
			firstCol = Math.max(0, firstCol);
			var lastCol = Math.floor(lastX / this.columnWidth);
			lastCol -= lastX % this.columnWidth ? 0 : 1;
			lastCol = Math.min(this.cols - 1, lastCol);
			var stampMaxY = (this._getOption("originTop") ? offset.top : offset.bottom) + stampSize.outerHeight;
			for (var i = firstCol; i <= lastCol; i++) this.colYs[i] = Math.max(stampMaxY, this.colYs[i]);
		};
		proto._getContainerSize = function() {
			this.maxY = Math.max.apply(Math, this.colYs);
			var size = { height: this.maxY };
			if (this._getOption("fitWidth")) size.width = this._getContainerFitWidth();
			return size;
		};
		proto._getContainerFitWidth = function() {
			var unusedCols = 0;
			var i = this.cols;
			while (--i) {
				if (this.colYs[i] !== 0) break;
				unusedCols++;
			}
			return (this.cols - unusedCols) * this.columnWidth - this.gutter;
		};
		proto.needsResizeLayout = function() {
			var previousWidth = this.containerWidth;
			this.getContainerWidth();
			return previousWidth != this.containerWidth;
		};
		return Masonry;
	});
}));
//#endregion
//#region node_modules/isotope-layout/js/layout-modes/masonry.js
var require_masonry = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	/*!
	* Masonry layout mode
	* sub-classes Masonry
	* https://masonry.desandro.com
	*/
	(function(window, factory) {
		if (typeof define == "function" && define.amd) define(["../layout-mode", "masonry-layout/masonry"], factory);
		else if (typeof module == "object" && module.exports) module.exports = factory(require_layout_mode(), require_masonry$1());
		else factory(window.Isotope.LayoutMode, window.Masonry);
	})(window, function factory(LayoutMode, Masonry) {
		"use strict";
		var MasonryMode = LayoutMode.create("masonry");
		var proto = MasonryMode.prototype;
		var keepModeMethods = {
			_getElementOffset: true,
			layout: true,
			_getMeasurement: true
		};
		for (var method in Masonry.prototype) if (!keepModeMethods[method]) proto[method] = Masonry.prototype[method];
		var measureColumns = proto.measureColumns;
		proto.measureColumns = function() {
			this.items = this.isotope.filteredItems;
			measureColumns.call(this);
		};
		var _getOption = proto._getOption;
		proto._getOption = function(option) {
			if (option == "fitWidth") return this.options.isFitWidth !== void 0 ? this.options.isFitWidth : this.options.fitWidth;
			return _getOption.apply(this.isotope, arguments);
		};
		return MasonryMode;
	});
}));
//#endregion
//#region node_modules/isotope-layout/js/layout-modes/fit-rows.js
var require_fit_rows = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	/**
	* fitRows layout mode
	*/
	(function(window, factory) {
		if (typeof define == "function" && define.amd) define(["../layout-mode"], factory);
		else if (typeof exports == "object") module.exports = factory(require_layout_mode());
		else factory(window.Isotope.LayoutMode);
	})(window, function factory(LayoutMode) {
		"use strict";
		var FitRows = LayoutMode.create("fitRows");
		var proto = FitRows.prototype;
		proto._resetLayout = function() {
			this.x = 0;
			this.y = 0;
			this.maxY = 0;
			this._getMeasurement("gutter", "outerWidth");
		};
		proto._getItemLayoutPosition = function(item) {
			item.getSize();
			var itemWidth = item.size.outerWidth + this.gutter;
			var containerWidth = this.isotope.size.innerWidth + this.gutter;
			if (this.x !== 0 && itemWidth + this.x > containerWidth) {
				this.x = 0;
				this.y = this.maxY;
			}
			var position = {
				x: this.x,
				y: this.y
			};
			this.maxY = Math.max(this.maxY, this.y + item.size.outerHeight);
			this.x += itemWidth;
			return position;
		};
		proto._getContainerSize = function() {
			return { height: this.maxY };
		};
		return FitRows;
	});
}));
//#endregion
//#region node_modules/isotope-layout/js/layout-modes/vertical.js
var require_vertical = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	/**
	* vertical layout mode
	*/
	(function(window, factory) {
		if (typeof define == "function" && define.amd) define(["../layout-mode"], factory);
		else if (typeof module == "object" && module.exports) module.exports = factory(require_layout_mode());
		else factory(window.Isotope.LayoutMode);
	})(window, function factory(LayoutMode) {
		"use strict";
		var Vertical = LayoutMode.create("vertical", { horizontalAlignment: 0 });
		var proto = Vertical.prototype;
		proto._resetLayout = function() {
			this.y = 0;
		};
		proto._getItemLayoutPosition = function(item) {
			item.getSize();
			var x = (this.isotope.size.innerWidth - item.size.outerWidth) * this.options.horizontalAlignment;
			var y = this.y;
			this.y += item.size.outerHeight;
			return {
				x,
				y
			};
		};
		proto._getContainerSize = function() {
			return { height: this.y };
		};
		return Vertical;
	});
}));
//#endregion
//#region node_modules/isotope-layout/js/isotope.js
var require_isotope = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	/*!
	* Isotope v3.0.6
	*
	* Licensed GPLv3 for open source use
	* or Isotope Commercial License for commercial use
	*
	* https://isotope.metafizzy.co
	* Copyright 2010-2018 Metafizzy
	*/
	(function(window, factory) {
		if (typeof define == "function" && define.amd) define([
			"outlayer/outlayer",
			"get-size/get-size",
			"desandro-matches-selector/matches-selector",
			"fizzy-ui-utils/utils",
			"./item",
			"./layout-mode",
			"./layout-modes/masonry",
			"./layout-modes/fit-rows",
			"./layout-modes/vertical"
		], function(Outlayer, getSize, matchesSelector, utils, Item, LayoutMode) {
			return factory(window, Outlayer, getSize, matchesSelector, utils, Item, LayoutMode);
		});
		else if (typeof module == "object" && module.exports) module.exports = factory(window, require_outlayer(), require_get_size(), require_matches_selector(), require_utils(), require_item(), require_layout_mode(), require_masonry(), require_fit_rows(), require_vertical());
		else window.Isotope = factory(window, window.Outlayer, window.getSize, window.matchesSelector, window.fizzyUIUtils, window.Isotope.Item, window.Isotope.LayoutMode);
	})(window, function factory(window, Outlayer, getSize, matchesSelector, utils, Item, LayoutMode) {
		"use strict";
		var jQuery = window.jQuery;
		var trim = String.prototype.trim ? function(str) {
			return str.trim();
		} : function(str) {
			return str.replace(/^\s+|\s+$/g, "");
		};
		var Isotope = Outlayer.create("isotope", {
			layoutMode: "masonry",
			isJQueryFiltering: true,
			sortAscending: true
		});
		Isotope.Item = Item;
		Isotope.LayoutMode = LayoutMode;
		var proto = Isotope.prototype;
		proto._create = function() {
			this.itemGUID = 0;
			this._sorters = {};
			this._getSorters();
			Outlayer.prototype._create.call(this);
			this.modes = {};
			this.filteredItems = this.items;
			this.sortHistory = ["original-order"];
			for (var name in LayoutMode.modes) this._initLayoutMode(name);
		};
		proto.reloadItems = function() {
			this.itemGUID = 0;
			Outlayer.prototype.reloadItems.call(this);
		};
		proto._itemize = function() {
			var items = Outlayer.prototype._itemize.apply(this, arguments);
			for (var i = 0; i < items.length; i++) {
				var item = items[i];
				item.id = this.itemGUID++;
			}
			this._updateItemsSortData(items);
			return items;
		};
		proto._initLayoutMode = function(name) {
			var Mode = LayoutMode.modes[name];
			var initialOpts = this.options[name] || {};
			this.options[name] = Mode.options ? utils.extend(Mode.options, initialOpts) : initialOpts;
			this.modes[name] = new Mode(this);
		};
		proto.layout = function() {
			if (!this._isLayoutInited && this._getOption("initLayout")) {
				this.arrange();
				return;
			}
			this._layout();
		};
		proto._layout = function() {
			var isInstant = this._getIsInstant();
			this._resetLayout();
			this._manageStamps();
			this.layoutItems(this.filteredItems, isInstant);
			this._isLayoutInited = true;
		};
		proto.arrange = function(opts) {
			this.option(opts);
			this._getIsInstant();
			var filtered = this._filter(this.items);
			this.filteredItems = filtered.matches;
			this._bindArrangeComplete();
			if (this._isInstant) this._noTransition(this._hideReveal, [filtered]);
			else this._hideReveal(filtered);
			this._sort();
			this._layout();
		};
		proto._init = proto.arrange;
		proto._hideReveal = function(filtered) {
			this.reveal(filtered.needReveal);
			this.hide(filtered.needHide);
		};
		proto._getIsInstant = function() {
			var isLayoutInstant = this._getOption("layoutInstant");
			var isInstant = isLayoutInstant !== void 0 ? isLayoutInstant : !this._isLayoutInited;
			this._isInstant = isInstant;
			return isInstant;
		};
		proto._bindArrangeComplete = function() {
			var isLayoutComplete, isHideComplete, isRevealComplete;
			var _this = this;
			function arrangeParallelCallback() {
				if (isLayoutComplete && isHideComplete && isRevealComplete) _this.dispatchEvent("arrangeComplete", null, [_this.filteredItems]);
			}
			this.once("layoutComplete", function() {
				isLayoutComplete = true;
				arrangeParallelCallback();
			});
			this.once("hideComplete", function() {
				isHideComplete = true;
				arrangeParallelCallback();
			});
			this.once("revealComplete", function() {
				isRevealComplete = true;
				arrangeParallelCallback();
			});
		};
		proto._filter = function(items) {
			var filter = this.options.filter;
			filter = filter || "*";
			var matches = [];
			var hiddenMatched = [];
			var visibleUnmatched = [];
			var test = this._getFilterTest(filter);
			for (var i = 0; i < items.length; i++) {
				var item = items[i];
				if (item.isIgnored) continue;
				var isMatched = test(item);
				if (isMatched) matches.push(item);
				if (isMatched && item.isHidden) hiddenMatched.push(item);
				else if (!isMatched && !item.isHidden) visibleUnmatched.push(item);
			}
			return {
				matches,
				needReveal: hiddenMatched,
				needHide: visibleUnmatched
			};
		};
		proto._getFilterTest = function(filter) {
			if (jQuery && this.options.isJQueryFiltering) return function(item) {
				return jQuery(item.element).is(filter);
			};
			if (typeof filter == "function") return function(item) {
				return filter(item.element);
			};
			return function(item) {
				return matchesSelector(item.element, filter);
			};
		};
		/**
		* @params {Array} elems
		* @public
		*/
		proto.updateSortData = function(elems) {
			var items;
			if (elems) {
				elems = utils.makeArray(elems);
				items = this.getItems(elems);
			} else items = this.items;
			this._getSorters();
			this._updateItemsSortData(items);
		};
		proto._getSorters = function() {
			var getSortData = this.options.getSortData;
			for (var key in getSortData) {
				var sorter = getSortData[key];
				this._sorters[key] = mungeSorter(sorter);
			}
		};
		/**
		* @params {Array} items - of Isotope.Items
		* @private
		*/
		proto._updateItemsSortData = function(items) {
			var len = items && items.length;
			for (var i = 0; len && i < len; i++) items[i].updateSortData();
		};
		var mungeSorter = (function() {
			function mungeSorter(sorter) {
				if (typeof sorter != "string") return sorter;
				var args = trim(sorter).split(" ");
				var query = args[0];
				var attrMatch = query.match(/^\[(.+)\]$/);
				var getValue = getValueGetter(attrMatch && attrMatch[1], query);
				var parser = Isotope.sortDataParsers[args[1]];
				sorter = parser ? function(elem) {
					return elem && parser(getValue(elem));
				} : function(elem) {
					return elem && getValue(elem);
				};
				return sorter;
			}
			function getValueGetter(attr, query) {
				if (attr) return function getAttribute(elem) {
					return elem.getAttribute(attr);
				};
				return function getChildText(elem) {
					var child = elem.querySelector(query);
					return child && child.textContent;
				};
			}
			return mungeSorter;
		})();
		Isotope.sortDataParsers = {
			"parseInt": function(val) {
				return parseInt(val, 10);
			},
			"parseFloat": function(val) {
				return parseFloat(val);
			}
		};
		proto._sort = function() {
			if (!this.options.sortBy) return;
			var sortBys = utils.makeArray(this.options.sortBy);
			if (!this._getIsSameSortBy(sortBys)) this.sortHistory = sortBys.concat(this.sortHistory);
			var itemSorter = getItemSorter(this.sortHistory, this.options.sortAscending);
			this.filteredItems.sort(itemSorter);
		};
		proto._getIsSameSortBy = function(sortBys) {
			for (var i = 0; i < sortBys.length; i++) if (sortBys[i] != this.sortHistory[i]) return false;
			return true;
		};
		function getItemSorter(sortBys, sortAsc) {
			return function sorter(itemA, itemB) {
				for (var i = 0; i < sortBys.length; i++) {
					var sortBy = sortBys[i];
					var a = itemA.sortData[sortBy];
					var b = itemB.sortData[sortBy];
					if (a > b || a < b) {
						var direction = (sortAsc[sortBy] !== void 0 ? sortAsc[sortBy] : sortAsc) ? 1 : -1;
						return (a > b ? 1 : -1) * direction;
					}
				}
				return 0;
			};
		}
		proto._mode = function() {
			var layoutMode = this.options.layoutMode;
			var mode = this.modes[layoutMode];
			if (!mode) throw new Error("No layout mode: " + layoutMode);
			mode.options = this.options[layoutMode];
			return mode;
		};
		proto._resetLayout = function() {
			Outlayer.prototype._resetLayout.call(this);
			this._mode()._resetLayout();
		};
		proto._getItemLayoutPosition = function(item) {
			return this._mode()._getItemLayoutPosition(item);
		};
		proto._manageStamp = function(stamp) {
			this._mode()._manageStamp(stamp);
		};
		proto._getContainerSize = function() {
			return this._mode()._getContainerSize();
		};
		proto.needsResizeLayout = function() {
			return this._mode().needsResizeLayout();
		};
		proto.appended = function(elems) {
			var items = this.addItems(elems);
			if (!items.length) return;
			var filteredItems = this._filterRevealAdded(items);
			this.filteredItems = this.filteredItems.concat(filteredItems);
		};
		proto.prepended = function(elems) {
			var items = this._itemize(elems);
			if (!items.length) return;
			this._resetLayout();
			this._manageStamps();
			var filteredItems = this._filterRevealAdded(items);
			this.layoutItems(this.filteredItems);
			this.filteredItems = filteredItems.concat(this.filteredItems);
			this.items = items.concat(this.items);
		};
		proto._filterRevealAdded = function(items) {
			var filtered = this._filter(items);
			this.hide(filtered.needHide);
			this.reveal(filtered.matches);
			this.layoutItems(filtered.matches, true);
			return filtered.matches;
		};
		/**
		* Filter, sort, and layout newly-appended item elements
		* @param {Array or NodeList or Element} elems
		*/
		proto.insert = function(elems) {
			var items = this.addItems(elems);
			if (!items.length) return;
			var i, item;
			var len = items.length;
			for (i = 0; i < len; i++) {
				item = items[i];
				this.element.appendChild(item.element);
			}
			var filteredInsertItems = this._filter(items).matches;
			for (i = 0; i < len; i++) items[i].isLayoutInstant = true;
			this.arrange();
			for (i = 0; i < len; i++) delete items[i].isLayoutInstant;
			this.reveal(filteredInsertItems);
		};
		var _remove = proto.remove;
		proto.remove = function(elems) {
			elems = utils.makeArray(elems);
			var removeItems = this.getItems(elems);
			_remove.call(this, elems);
			var len = removeItems && removeItems.length;
			for (var i = 0; len && i < len; i++) {
				var item = removeItems[i];
				utils.removeFrom(this.filteredItems, item);
			}
		};
		proto.shuffle = function() {
			for (var i = 0; i < this.items.length; i++) {
				var item = this.items[i];
				item.sortData.random = Math.random();
			}
			this.options.sortBy = "random";
			this._sort();
			this._layout();
		};
		/**
		* trigger fn without transition
		* kind of hacky to have this in the first place
		* @param {Function} fn
		* @param {Array} args
		* @returns ret
		* @private
		*/
		proto._noTransition = function(fn, args) {
			var transitionDuration = this.options.transitionDuration;
			this.options.transitionDuration = 0;
			var returnValue = fn.apply(this, args);
			this.options.transitionDuration = transitionDuration;
			return returnValue;
		};
		/**
		* getter method for getting filtered item elements
		* @returns {Array} elems - collection of item elements
		*/
		proto.getFilteredItemElements = function() {
			return this.filteredItems.map(function(item) {
				return item.element;
			});
		};
		return Isotope;
	});
}));
//#endregion
export { require_isotope as t };
