import { t as __commonJSMin } from "../_runtime.mjs";
import { t as require_matches_selector } from "./desandro-matches-selector.mjs";
//#region node_modules/fizzy-ui-utils/utils.js
var require_utils = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	/**
	* Fizzy UI utils v2.0.7
	* MIT license
	*/
	(function(window, factory) {
		if (typeof define == "function" && define.amd) define(["desandro-matches-selector/matches-selector"], function(matchesSelector) {
			return factory(window, matchesSelector);
		});
		else if (typeof module == "object" && module.exports) module.exports = factory(window, require_matches_selector());
		else window.fizzyUIUtils = factory(window, window.matchesSelector);
	})(window, function factory(window, matchesSelector) {
		"use strict";
		var utils = {};
		utils.extend = function(a, b) {
			for (var prop in b) a[prop] = b[prop];
			return a;
		};
		utils.modulo = function(num, div) {
			return (num % div + div) % div;
		};
		var arraySlice = Array.prototype.slice;
		utils.makeArray = function(obj) {
			if (Array.isArray(obj)) return obj;
			if (obj === null || obj === void 0) return [];
			if (typeof obj == "object" && typeof obj.length == "number") return arraySlice.call(obj);
			return [obj];
		};
		utils.removeFrom = function(ary, obj) {
			var index = ary.indexOf(obj);
			if (index != -1) ary.splice(index, 1);
		};
		utils.getParent = function(elem, selector) {
			while (elem.parentNode && elem != document.body) {
				elem = elem.parentNode;
				if (matchesSelector(elem, selector)) return elem;
			}
		};
		utils.getQueryElement = function(elem) {
			if (typeof elem == "string") return document.querySelector(elem);
			return elem;
		};
		utils.handleEvent = function(event) {
			var method = "on" + event.type;
			if (this[method]) this[method](event);
		};
		utils.filterFindElements = function(elems, selector) {
			elems = utils.makeArray(elems);
			var ffElems = [];
			elems.forEach(function(elem) {
				if (!(elem instanceof HTMLElement)) return;
				if (!selector) {
					ffElems.push(elem);
					return;
				}
				if (matchesSelector(elem, selector)) ffElems.push(elem);
				var childElems = elem.querySelectorAll(selector);
				for (var i = 0; i < childElems.length; i++) ffElems.push(childElems[i]);
			});
			return ffElems;
		};
		utils.debounceMethod = function(_class, methodName, threshold) {
			threshold = threshold || 100;
			var method = _class.prototype[methodName];
			var timeoutName = methodName + "Timeout";
			_class.prototype[methodName] = function() {
				var timeout = this[timeoutName];
				clearTimeout(timeout);
				var args = arguments;
				var _this = this;
				this[timeoutName] = setTimeout(function() {
					method.apply(_this, args);
					delete _this[timeoutName];
				}, threshold);
			};
		};
		utils.docReady = function(callback) {
			var readyState = document.readyState;
			if (readyState == "complete" || readyState == "interactive") setTimeout(callback);
			else document.addEventListener("DOMContentLoaded", callback);
		};
		utils.toDashed = function(str) {
			return str.replace(/(.)([A-Z])/g, function(match, $1, $2) {
				return $1 + "-" + $2;
			}).toLowerCase();
		};
		var console = window.console;
		/**
		* allow user to initialize classes via [data-namespace] or .js-namespace class
		* htmlInit( Widget, 'widgetName' )
		* options are parsed from data-namespace-options
		*/
		utils.htmlInit = function(WidgetClass, namespace) {
			utils.docReady(function() {
				var dashedNamespace = utils.toDashed(namespace);
				var dataAttr = "data-" + dashedNamespace;
				var dataAttrElems = document.querySelectorAll("[" + dataAttr + "]");
				var jsDashElems = document.querySelectorAll(".js-" + dashedNamespace);
				var elems = utils.makeArray(dataAttrElems).concat(utils.makeArray(jsDashElems));
				var dataOptionsAttr = dataAttr + "-options";
				var jQuery = window.jQuery;
				elems.forEach(function(elem) {
					var attr = elem.getAttribute(dataAttr) || elem.getAttribute(dataOptionsAttr);
					var options;
					try {
						options = attr && JSON.parse(attr);
					} catch (error) {
						if (console) console.error("Error parsing " + dataAttr + " on " + elem.className + ": " + error);
						return;
					}
					var instance = new WidgetClass(elem, options);
					if (jQuery) jQuery.data(elem, namespace, instance);
				});
			});
		};
		return utils;
	});
}));
//#endregion
export { require_utils as t };
