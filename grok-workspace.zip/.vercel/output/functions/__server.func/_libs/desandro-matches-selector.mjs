import { t as __commonJSMin } from "../_runtime.mjs";
//#region node_modules/desandro-matches-selector/matches-selector.js
var require_matches_selector = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	/**
	* matchesSelector v2.0.2
	* matchesSelector( element, '.selector' )
	* MIT license
	*/
	(function(window, factory) {
		"use strict";
		if (typeof define == "function" && define.amd) define(factory);
		else if (typeof module == "object" && module.exports) module.exports = factory();
		else window.matchesSelector = factory();
	})(window, function factory() {
		"use strict";
		var matchesMethod = (function() {
			var ElemProto = window.Element.prototype;
			if (ElemProto.matches) return "matches";
			if (ElemProto.matchesSelector) return "matchesSelector";
			var prefixes = [
				"webkit",
				"moz",
				"ms",
				"o"
			];
			for (var i = 0; i < prefixes.length; i++) {
				var method = prefixes[i] + "MatchesSelector";
				if (ElemProto[method]) return method;
			}
		})();
		return function matchesSelector(elem, selector) {
			return elem[matchesMethod](selector);
		};
	});
}));
//#endregion
export { require_matches_selector as t };
