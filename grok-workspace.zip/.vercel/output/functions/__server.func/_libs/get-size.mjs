import { t as __commonJSMin } from "../_runtime.mjs";
//#region node_modules/get-size/get-size.js
var require_get_size = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	/*!
	* getSize v2.0.3
	* measure size of elements
	* MIT license
	*/
	(function(window, factory) {
		if (typeof define == "function" && define.amd) define(factory);
		else if (typeof module == "object" && module.exports) module.exports = factory();
		else window.getSize = factory();
	})(window, function factory() {
		"use strict";
		function getStyleSize(value) {
			var num = parseFloat(value);
			return value.indexOf("%") == -1 && !isNaN(num) && num;
		}
		function noop() {}
		var logError = typeof console == "undefined" ? noop : function(message) {
			console.error(message);
		};
		var measurements = [
			"paddingLeft",
			"paddingRight",
			"paddingTop",
			"paddingBottom",
			"marginLeft",
			"marginRight",
			"marginTop",
			"marginBottom",
			"borderLeftWidth",
			"borderRightWidth",
			"borderTopWidth",
			"borderBottomWidth"
		];
		var measurementsLength = measurements.length;
		function getZeroSize() {
			var size = {
				width: 0,
				height: 0,
				innerWidth: 0,
				innerHeight: 0,
				outerWidth: 0,
				outerHeight: 0
			};
			for (var i = 0; i < measurementsLength; i++) {
				var measurement = measurements[i];
				size[measurement] = 0;
			}
			return size;
		}
		/**
		* getStyle, get style of element, check for Firefox bug
		* https://bugzilla.mozilla.org/show_bug.cgi?id=548397
		*/
		function getStyle(elem) {
			var style = getComputedStyle(elem);
			if (!style) logError("Style returned " + style + ". Are you running this code in a hidden iframe on Firefox? See https://bit.ly/getsizebug1");
			return style;
		}
		var isSetup = false;
		var isBoxSizeOuter;
		/**
		* setup
		* check isBoxSizerOuter
		* do on first getSize() rather than on page load for Firefox bug
		*/
		function setup() {
			if (isSetup) return;
			isSetup = true;
			/**
			* Chrome & Safari measure the outer-width on style.width on border-box elems
			* IE11 & Firefox<29 measures the inner-width
			*/
			var div = document.createElement("div");
			div.style.width = "200px";
			div.style.padding = "1px 2px 3px 4px";
			div.style.borderStyle = "solid";
			div.style.borderWidth = "1px 2px 3px 4px";
			div.style.boxSizing = "border-box";
			var body = document.body || document.documentElement;
			body.appendChild(div);
			var style = getStyle(div);
			isBoxSizeOuter = Math.round(getStyleSize(style.width)) == 200;
			getSize.isBoxSizeOuter = isBoxSizeOuter;
			body.removeChild(div);
		}
		function getSize(elem) {
			setup();
			if (typeof elem == "string") elem = document.querySelector(elem);
			if (!elem || typeof elem != "object" || !elem.nodeType) return;
			var style = getStyle(elem);
			if (style.display == "none") return getZeroSize();
			var size = {};
			size.width = elem.offsetWidth;
			size.height = elem.offsetHeight;
			var isBorderBox = size.isBorderBox = style.boxSizing == "border-box";
			for (var i = 0; i < measurementsLength; i++) {
				var measurement = measurements[i];
				var value = style[measurement];
				var num = parseFloat(value);
				size[measurement] = !isNaN(num) ? num : 0;
			}
			var paddingWidth = size.paddingLeft + size.paddingRight;
			var paddingHeight = size.paddingTop + size.paddingBottom;
			var marginWidth = size.marginLeft + size.marginRight;
			var marginHeight = size.marginTop + size.marginBottom;
			var borderWidth = size.borderLeftWidth + size.borderRightWidth;
			var borderHeight = size.borderTopWidth + size.borderBottomWidth;
			var isBorderBoxSizeOuter = isBorderBox && isBoxSizeOuter;
			var styleWidth = getStyleSize(style.width);
			if (styleWidth !== false) size.width = styleWidth + (isBorderBoxSizeOuter ? 0 : paddingWidth + borderWidth);
			var styleHeight = getStyleSize(style.height);
			if (styleHeight !== false) size.height = styleHeight + (isBorderBoxSizeOuter ? 0 : paddingHeight + borderHeight);
			size.innerWidth = size.width - (paddingWidth + borderWidth);
			size.innerHeight = size.height - (paddingHeight + borderHeight);
			size.outerWidth = size.width + marginWidth;
			size.outerHeight = size.height + marginHeight;
			return size;
		}
		return getSize;
	});
}));
//#endregion
export { require_get_size as t };
