import { i as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, Y as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { o as HOURS, s as SHOP } from "./basket-store-Bul83CGW.mjs";
import { i as PageHead } from "./router-uVvk7cxV.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/contact-CDL3pGHM.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ContactPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
		pt: "Fale connosco",
		en: "Contact",
		deck: "The counter answers. If we are in the middle of a reading, it may be after eight.",
		image: "https://images.unsplash.com/photo-1457369804613-52c61a468e7d?auto=format&fit=crop&w=2000&q=80",
		imageAlt: "An open notebook beside a cup of tea"
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "ma-section",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "ma-wrap",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "row g-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "col-lg-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "ma-h2 ma-h2--left",
							children: "The shop"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("address", {
							className: "ma-address",
							children: [SHOP.address.map((line) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: line }, line)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: SHOP.neighbourhood })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: SHOP.phoneHref,
								children: SHOP.phone
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: SHOP.emailHref,
								children: SHOP.email
							})
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "ma-h3",
							children: "Horário · Opening hours"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "ma-hours",
							children: HOURS.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: row.days }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: row.hours })] }, row.days))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "ma-map",
							role: "img",
							"aria-label": "Map placeholder for Rua da Boavista, Lisbon",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
								viewBox: "0 0 320 220",
								"aria-hidden": "true",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
										width: "320",
										height: "220",
										fill: "#E7E2D8"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
										d: "M0 150 H320 M40 0 V220 M180 0 V220 M0 70 H320 M260 0 V220",
										stroke: "#1E2430",
										strokeOpacity: "0.15"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
										d: "M20 170 C 80 150, 120 120, 200 130 S 280 90, 310 80",
										fill: "none",
										stroke: "#1F4E8C",
										strokeWidth: "6"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
										cx: "168",
										cy: "128",
										r: "8",
										fill: "#E0663A"
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Maré Alta" }), "Map placeholder — Rua da Boavista 18, uphill from Cais do Sodré."] })]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "col-lg-7",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "ma-h2 ma-h2--left",
						children: "A message"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageForm, {})]
				})]
			})
		})
	})] });
}
function MessageForm() {
	const [done, setDone] = (0, import_react.useState)(false);
	function onSubmit(event) {
		event.preventDefault();
		setDone(true);
	}
	if (done) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "ma-form__done",
		role: "status",
		children: "Received on this page. On a live shop this would go to ola@marealta.pt. Nothing was stored."
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		className: "ma-form ma-form--stack",
		onSubmit,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
				htmlFor: "msg-name",
				children: "Name"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				id: "msg-name",
				name: "name",
				required: true,
				autoComplete: "name"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
				htmlFor: "msg-email",
				children: "Email"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				id: "msg-email",
				name: "email",
				type: "email",
				required: true,
				autoComplete: "email"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
				htmlFor: "msg-about",
				children: "About"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
				id: "msg-about",
				name: "about",
				defaultValue: "visit",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "visit",
						children: "A visit or a reserved book"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "event",
						children: "An event"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "club",
						children: "The book club"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "other",
						children: "Something else"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
				htmlFor: "msg-body",
				children: "Message"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
				id: "msg-body",
				name: "message",
				rows: 6,
				required: true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "submit",
				className: "ma-btn ma-btn--accent",
				children: "Send the note"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "ma-fine",
				children: "Concept shop: the form is not connected to an inbox. For EU customers, a live shop would add a privacy policy before collecting anything."
			})
		]
	});
}
//#endregion
export { ContactPage as component };
