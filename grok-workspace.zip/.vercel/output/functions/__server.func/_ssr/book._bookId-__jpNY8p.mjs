import { i as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, Y as require_react, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as STAFF_PICKS, d as getBook, f as useBasket, l as categoryLabel, t as BOOKS, u as formatPrice } from "./basket-store-Bul83CGW.mjs";
import { n as Route } from "./router-uVvk7cxV.mjs";
import { t as BookCover } from "./BookCover-J8GnyYfz.mjs";
import { t as BookCard } from "./BookCard-DYILD5xy.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/book._bookId-__jpNY8p.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function BookPage() {
	const { bookId } = Route.useParams();
	const book = getBook(bookId);
	const add = useBasket((s) => s.add);
	const [added, setAdded] = (0, import_react.useState)(false);
	if (!book) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "ma-wrap ma-missing",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "ma-kicker",
				children: "Esgotado"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", { children: "We don’t have that one on the table." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/shop",
				search: {
					q: "",
					cat: "all",
					sort: "featured"
				},
				className: "ma-btn ma-btn--ink",
				children: "Back to the shop"
			})
		]
	});
	const notes = STAFF_PICKS.filter((pick) => pick.bookId === book.id);
	const related = BOOKS.filter((other) => other.category === book.category && other.id !== book.id).slice(0, 4);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("article", {
		className: "ma-section",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "ma-wrap",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "ma-crumb",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/",
							children: "Home"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							"aria-hidden": "true",
							children: " / "
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/shop",
							search: {
								q: "",
								cat: book.category,
								sort: "featured"
							},
							children: categoryLabel(book.category)
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "row g-5 align-items-start",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "col-md-5 col-lg-4",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookCover, { book })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "col-md-7 col-lg-8",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "ma-kicker ma-kicker--left",
								children: categoryLabel(book.category)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "ma-booktitle",
								children: book.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "ma-bookauthor",
								children: book.author
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "ma-bookprice",
								children: formatPrice(book.price)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "ma-prose",
								children: book.description
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "ma-lang",
								children: ["Language · ", book.language]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "ma-btn ma-btn--accent",
								onClick: () => {
									add(book.id);
									setAdded(true);
									window.setTimeout(() => setAdded(false), 1400);
								},
								children: added ? "Added" : "Add to basket"
							}),
							notes.map((note) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("blockquote", {
								className: "ma-quote",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: note.note }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", { children: [
									note.bookseller,
									", ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("cite", { children: note.role })
								] })]
							}, note.bookseller))
						]
					})]
				}),
				related.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "ma-related",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "ma-kicker",
							children: "Na mesma mesa"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
							className: "ma-h2",
							children: ["Also in ", categoryLabel(book.category).toLowerCase()]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "ma-home-grid",
							children: related.map((other) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookCard, {
								book: other,
								showButton: true
							}, other.id))
						})
					]
				}) : null
			]
		})
	});
}
//#endregion
export { BookPage as component };
