import { i as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, S as useRouter, Y as require_react, _ as lazyRouteComponent, b as Link, d as Scripts, f as HeadContent, g as Outlet, h as createRouter, p as useRouterState, v as createFileRoute, x as useNavigate, y as createRootRoute } from "../_libs/@tanstack/react-router+[...].mjs";
import { d as getBook, f as useBasket, o as HOURS, s as SHOP, t as BOOKS, u as formatPrice } from "./basket-store-Bul83CGW.mjs";
import { a as ShoppingBag, c as Minus, i as TriangleAlert, l as Menu, n as Waves, o as Search, s as Plus, t as X } from "../_libs/lucide-react.mjs";
import { a as union, i as string, n as number, r as object, t as literal } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-uVvk7cxV.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var FALLBACK_MESSAGE = "An unexpected error occurred. Try reloading the page.";
function errorMessage(error) {
	if (error instanceof Error && error.message) return error.message;
	if (typeof error === "string" && error) return error;
	return FALLBACK_MESSAGE;
}
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 px-6 text-center bg-zinc-50 text-zinc-900 dark:bg-zinc-950 dark:text-zinc-50",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-red-500",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-lg font-semibold",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-zinc-500 dark:text-zinc-400",
				children: errorMessage(error)
			})
		]
	});
}
/**
* Path-based preview hosts serve the dev server under `/{port_id}/` and strip
* that prefix before forwarding, so SSR sees `/` while the browser URL keeps the
* prefix. TanStack Start resets `basepath` on hydration, so a `rewrite` keeps
* client routing and generated links aligned with the public URL.
*/
var PATH_BASED_PREVIEW_HOSTS = /* @__PURE__ */ new Set([
	"preview.grok.genai.mil",
	"preview.grok.mil",
	"preview.grokgsac.com"
]);
var PORT_ID_PREFIX = /^\/hds-[a-z0-9]+-\d+-[a-z0-9]+(?=\/|$)/i;
function previewPathPrefix(hostname, pathname) {
	if (!PATH_BASED_PREVIEW_HOSTS.has(hostname.toLowerCase())) return void 0;
	return PORT_ID_PREFIX.exec(pathname)?.[0];
}
function prefixRewrite(prefix) {
	return {
		input: ({ url }) => {
			if (url.pathname === prefix) url.pathname = "/";
			else if (url.pathname.startsWith(`${prefix}/`)) url.pathname = url.pathname.slice(prefix.length);
			return url;
		},
		output: ({ url }) => {
			url.pathname = `${prefix}${url.pathname}`;
			return url;
		}
	};
}
function previewPathRewrite() {
	if (typeof window === "undefined") return void 0;
	const prefix = previewPathPrefix(window.location.hostname, window.location.pathname);
	return prefix ? prefixRewrite(prefix) : void 0;
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
var CONNECTOR_TOKEN_READY_EVENT = "grok:connector-token-ready";
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
var ConnectorTokenReadySchema = EnvelopeSchema.extend({ type: literal("connector-token-ready") });
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Origin of the Grok embedder framing this page, or null when the page runs
* top-level (download/export, local `npm run dev`, deployed sites) or under a
* non-Grok parent. Client-only; null during SSR.
*/
function resolveCurrentEmbedderOrigin() {
	if (typeof window === "undefined") return null;
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	return resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	const parentOrigin = resolveCurrentEmbedderOrigin();
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onHello = (data) => {
		if (!HelloSchema.safeParse(data).success) return;
		announce();
	};
	const onNavigate = (data) => {
		const parsed = NavigateSchema.safeParse(data);
		if (!parsed.success) return;
		navigate(parsed.data.path);
		queueMicrotask(reportLocation);
	};
	const onHistory = (data) => {
		const parsed = HistorySchema.safeParse(data);
		if (!parsed.success) return;
		if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
		window.history.go(parsed.data.delta);
	};
	const onConnectorTokenReady = (data) => {
		if (!ConnectorTokenReadySchema.safeParse(data).success) return;
		window.dispatchEvent(new Event(CONNECTOR_TOKEN_READY_EVENT));
	};
	const hostMessageHandlers = /* @__PURE__ */ new Map([
		["hello", onHello],
		["navigate", onNavigate],
		["history", onHistory],
		["connector-token-ready", onConnectorTokenReady]
	]);
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		hostMessageHandlers.get(envelope.data.type)?.(event.data);
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
var NAV = [
	{
		to: "/",
		label: "Home",
		exact: true
	},
	{
		to: "/shop",
		label: "Shop",
		exact: true
	},
	{
		to: "/staff-picks",
		label: "Escolhas",
		exact: true
	},
	{
		to: "/events",
		label: "Events",
		exact: true
	},
	{
		to: "/about",
		label: "About",
		exact: true
	},
	{
		to: "/contact",
		label: "Contact",
		exact: true
	}
];
function SiteShell({ children }) {
	const navigate = useNavigate();
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	const lines = useBasket((s) => s.lines);
	const open = useBasket((s) => s.open);
	const setOpen = useBasket((s) => s.setOpen);
	const setQty = useBasket((s) => s.setQty);
	const remove = useBasket((s) => s.remove);
	const [menu, setMenu] = (0, import_react.useState)(false);
	const [searchOpen, setSearchOpen] = (0, import_react.useState)(false);
	const [q, setQ] = (0, import_react.useState)("");
	const [hydrated, setHydrated] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		useBasket.persist.rehydrate();
		setHydrated(true);
	}, []);
	(0, import_react.useEffect)(() => {
		setMenu(false);
		setSearchOpen(false);
	}, [pathname]);
	(0, import_react.useEffect)(() => {
		document.body.style.overflow = open || menu ? "hidden" : "";
		return () => {
			document.body.style.overflow = "";
		};
	}, [open, menu]);
	const count = hydrated ? lines.reduce((sum, line) => sum + line.qty, 0) : 0;
	const detailed = lines.map((line) => {
		const book = getBook(line.id);
		return book ? {
			...line,
			book
		} : null;
	}).filter((line) => line !== null);
	const subtotal = detailed.reduce((sum, line) => sum + line.book.price * line.qty, 0);
	function onSearch(event) {
		event.preventDefault();
		navigate({
			to: "/shop",
			search: {
				q: q.trim(),
				cat: "all",
				sort: "featured"
			}
		});
		setSearchOpen(false);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
			className: "ma-skip",
			href: "#content",
			children: "Skip to content"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "ma-topbar",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "ma-wrap ma-topbar__inner",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Waves, {
						size: 14,
						"aria-hidden": "true"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Uma livraria junto ao Tejo" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "ma-dot",
						"aria-hidden": "true"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Lisbon" })
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "ma-topbar__right",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: SHOP.phoneHref,
							children: SHOP.phone
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "ma-dot",
							"aria-hidden": "true"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Mon–Sat 10–20" })
					]
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "ma-header",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "ma-wrap ma-header__row",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "ma-iconbtn ma-burger",
						"aria-expanded": menu,
						"aria-controls": "site-menu",
						onClick: () => setMenu((v) => !v),
						children: [menu ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { size: 22 }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { size: 22 }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "ma-sr",
							children: menu ? "Close menu" : "Open menu"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/",
						className: "ma-logo",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogoMark, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "ma-logo__name",
							children: "Maré Alta"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "ma-logo__line",
							children: SHOP.line
						})] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
						className: "ma-nav",
						"aria-label": "Primary",
						children: NAV.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: item.to,
							activeOptions: { exact: item.exact },
							activeProps: { className: "is-active" },
							children: item.label
						}, item.to))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "ma-tools",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
								className: "ma-search ma-search--desk",
								onSubmit: onSearch,
								role: "search",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
										className: "ma-sr",
										htmlFor: "desk-search",
										children: "Search the shop"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										id: "desk-search",
										value: q,
										onChange: (event) => setQ(event.target.value),
										placeholder: "Search titles, authors"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "submit",
										className: "ma-iconbtn",
										"aria-label": "Search",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { size: 18 })
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								className: "ma-iconbtn ma-search-toggle",
								"aria-expanded": searchOpen,
								onClick: () => setSearchOpen((v) => !v),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { size: 20 }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "ma-sr",
									children: "Search"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								className: "ma-iconbtn ma-bag",
								onClick: () => setOpen(true),
								"aria-label": `Basket, ${count} ${count === 1 ? "book" : "books"}`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShoppingBag, { size: 20 }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "ma-bag__count",
									children: count
								})]
							})
						]
					})
				]
			}), searchOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "ma-search ma-search--mob",
				onSubmit: onSearch,
				role: "search",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "ma-sr",
						htmlFor: "mob-search",
						children: "Search the shop"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						id: "mob-search",
						value: q,
						onChange: (event) => setQ(event.target.value),
						placeholder: "Search titles, authors",
						autoFocus: true
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "submit",
						className: "ma-btn ma-btn--ink",
						children: "Search"
					})
				]
			}) : null]
		}),
		menu ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
			id: "site-menu",
			className: "ma-drawer-nav",
			"aria-label": "Mobile",
			children: NAV.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: item.to,
				activeOptions: { exact: item.exact },
				activeProps: { className: "is-active" },
				children: item.label
			}, item.to))
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
			id: "content",
			children
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
			className: "ma-footer",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "ma-azulejo-rule",
					"aria-hidden": "true"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "ma-wrap ma-footer__grid",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "ma-footer__name",
							children: "Maré Alta"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "ma-footer__tag",
							children: "High tide. A bookshop a short walk from the river, fuller in the evening."
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Visit" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "ma-footer__plain",
								children: [SHOP.address.map((line) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [line, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {})] }, line)), SHOP.neighbourhood]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "ma-footer__plain",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
										href: SHOP.phoneHref,
										children: SHOP.phone
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
										href: SHOP.emailHref,
										children: SHOP.email
									})
								]
							})
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Horário" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "ma-hours",
							children: HOURS.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: row.days }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: row.hours })] }, row.days))
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "The shelves" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
							className: "ma-footer__links",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/shop",
									search: {
										q: "",
										cat: "fiction",
										sort: "featured"
									},
									children: "Fiction"
								}) }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/shop",
									search: {
										q: "",
										cat: "portuguese",
										sort: "featured"
									},
									children: "Portuguese authors"
								}) }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/shop",
									search: {
										q: "",
										cat: "children",
										sort: "featured"
									},
									children: "Children"
								}) }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/events",
									children: "Book club"
								}) })
							]
						})] })
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "ma-wrap ma-footer__base",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "A concept shop. Names, books, events and prices are invented." }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
						"Photography via Unsplash. ",
						BOOKS.length,
						" titles on the table."
					] })]
				})
			]
		}),
		open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "ma-overlay",
			role: "presentation",
			onClick: () => setOpen(false)
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
			className: open ? "ma-basket is-open" : "ma-basket",
			"aria-hidden": !open,
			"aria-label": "Basket",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "ma-basket__head",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Basket" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "ma-iconbtn",
						onClick: () => setOpen(false),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { size: 20 }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "ma-sr",
							children: "Close basket"
						})]
					})]
				}),
				detailed.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "ma-basket__empty",
					children: "Nothing set aside yet. The table by the window is a good place to start."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "ma-basket__list",
					children: detailed.map((line) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "ma-basket__title",
								children: line.book.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "ma-basket__meta",
								children: line.book.author
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "ma-basket__meta",
								children: formatPrice(line.book.price)
							})
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "ma-qty",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setQty(line.id, line.qty - 1),
									"aria-label": `Fewer copies of ${line.book.title}`,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minus, { size: 14 })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: line.qty }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setQty(line.id, line.qty + 1),
									"aria-label": `More copies of ${line.book.title}`,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 14 })
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "ma-textbtn",
							onClick: () => remove(line.id),
							children: "Remove"
						})
					] }, line.id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "ma-basket__foot",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "ma-basket__sub",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "To set aside" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: formatPrice(subtotal) })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "ma-fine",
							children: "Ask us to keep these at the counter. This concept basket does not take payment."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/contact",
							className: "ma-btn ma-btn--accent ma-btn--block",
							onClick: () => setOpen(false),
							children: "Write to the shop"
						})
					]
				})
			]
		})
	] });
}
function LogoMark() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		className: "ma-mark",
		viewBox: "0 0 36 36",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				className: "ma-mark__tile",
				width: "36",
				height: "36",
				rx: "4"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				className: "ma-mark__wave",
				d: "M5 22c4.2-5.2 8-5.2 12.2 0S25.2 27.2 29.4 22",
				fill: "none",
				strokeWidth: "2",
				strokeLinecap: "round"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				className: "ma-mark__accent",
				d: "M5 15.5c4.2-5.2 8-5.2 12.2 0S25.2 20.7 29.4 15.5",
				fill: "none",
				strokeWidth: "1.6",
				strokeLinecap: "round"
			})
		]
	});
}
function PageHead({ pt, en, deck, image, imageAlt }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "ma-pagehead",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: image,
				alt: imageAlt
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "ma-pagehead__shade" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "ma-wrap ma-pagehead__copy",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "ma-kicker ma-kicker--light",
						children: pt
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", { children: en }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: deck })
				]
			})
		]
	});
}
var styles_default = "/assets/styles-C8MAuqRU.css";
var Route$7 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: "Maré Alta — a bookshop by the Tagus" },
			{
				name: "description",
				content: "Maré Alta is an independent bookshop in Lisbon. New books in Portuguese and English, Thursday readings, and a book club that fills up."
			},
			{
				name: "theme-color",
				content: "#1F4E8C"
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,520;0,9..144,640;1,9..144,520;1,9..144,640&family=Source+Sans+3:ital,wght@0,400;0,500;0,600;0,700;1,400;1,500&display=swap"
			}
		]
	}),
	notFoundComponent: function NotFound() {
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "ma-wrap ma-missing",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "ma-kicker",
					children: "Fora da estante"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", { children: "That page is not on the shelf." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/",
					className: "ma-btn ma-btn--ink",
					children: "Back to the shop"
				})
			]
		});
	},
	component: function Root() {
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
			lang: "en",
			suppressHydrationWarning: true,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) }) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
			] })]
		});
	}
});
var $$splitComponentImporter$6 = () => import("./routes-Bnifhrtn.mjs");
var Route$6 = createFileRoute("/")({
	head: () => ({ meta: [{ title: "Maré Alta — books chosen by people who have read them" }] }),
	component: lazyRouteComponent($$splitComponentImporter$6, "component")
});
var $$splitComponentImporter$5 = () => import("./about-hXQG8bD5.mjs");
var Route$5 = createFileRoute("/about")({
	head: () => ({ meta: [{ title: "About the shop — Maré Alta" }] }),
	component: lazyRouteComponent($$splitComponentImporter$5, "component")
});
var $$splitComponentImporter$4 = () => import("./contact-CDL3pGHM.mjs");
var Route$4 = createFileRoute("/contact")({
	head: () => ({ meta: [{ title: "Contact — Maré Alta" }] }),
	component: lazyRouteComponent($$splitComponentImporter$4, "component")
});
var $$splitComponentImporter$3 = () => import("./events-zv62qKeu.mjs");
var Route$3 = createFileRoute("/events")({
	head: () => ({ meta: [{ title: "Events and book club — Maré Alta" }] }),
	component: lazyRouteComponent($$splitComponentImporter$3, "component")
});
var $$splitComponentImporter$2 = () => import("./shop-Cmbrcyyq.mjs");
var CATS = [
	"all",
	"fiction",
	"nonfiction",
	"portuguese",
	"children",
	"poetry"
];
var SORTS = [
	"featured",
	"title",
	"price-asc",
	"price-desc"
];
var Route$2 = createFileRoute("/shop")({
	validateSearch: (search) => ({
		q: typeof search.q === "string" ? search.q : "",
		cat: CATS.includes(String(search.cat)) ? search.cat : "all",
		sort: SORTS.includes(String(search.sort)) ? search.sort : "featured"
	}),
	head: () => ({ meta: [{ title: "The shop — Maré Alta" }] }),
	component: lazyRouteComponent($$splitComponentImporter$2, "component")
});
var $$splitComponentImporter$1 = () => import("./staff-picks-BhkuYwS0.mjs");
var Route$1 = createFileRoute("/staff-picks")({
	head: () => ({ meta: [{ title: "Escolhas da casa — Maré Alta" }] }),
	component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
var $$splitComponentImporter = () => import("./book._bookId-__jpNY8p.mjs");
var Route = createFileRoute("/book/$bookId")({
	head: ({ params }) => {
		const book = getBook(params.bookId);
		return { meta: [{ title: book ? `${book.title} — Maré Alta` : "Book — Maré Alta" }] };
	},
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
var rootRouteChildren = {
	IndexRoute: Route$6.update({
		id: "/",
		path: "/",
		getParentRoute: () => Route$7
	}),
	AboutRoute: Route$5.update({
		id: "/about",
		path: "/about",
		getParentRoute: () => Route$7
	}),
	ContactRoute: Route$4.update({
		id: "/contact",
		path: "/contact",
		getParentRoute: () => Route$7
	}),
	EventsRoute: Route$3.update({
		id: "/events",
		path: "/events",
		getParentRoute: () => Route$7
	}),
	ShopRoute: Route$2.update({
		id: "/shop",
		path: "/shop",
		getParentRoute: () => Route$7
	}),
	StaffPicksRoute: Route$1.update({
		id: "/staff-picks",
		path: "/staff-picks",
		getParentRoute: () => Route$7
	}),
	BookBookIdRoute: Route.update({
		id: "/book/$bookId",
		path: "/book/$bookId",
		getParentRoute: () => Route$7
	})
};
var routeTree = Route$7._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		rewrite: previewPathRewrite(),
		defaultErrorComponent: AppErrorComponent
	});
}
//#endregion
export { PageHead as i, Route as n, Route$2 as r, router_exports as t };
