import { C as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as STAFF_PICKS, d as getBook, u as formatPrice } from "./basket-store-Bul83CGW.mjs";
import { i as PageHead } from "./router-uVvk7cxV.mjs";
import { t as BookCover } from "./BookCover-J8GnyYfz.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/staff-picks-BhkuYwS0.js
var import_jsx_runtime = require_jsx_runtime();
function StaffPicksPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
		pt: "Escolhas da casa",
		en: "Staff picks",
		deck: "Six books. Each note is two sentences from the person who actually reads them at the till.",
		image: "https://images.unsplash.com/photo-1519682337058-a94d519337bc?auto=format&fit=crop&w=2000&q=80",
		imageAlt: "An open book on a dark table"
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "ma-section",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "ma-wrap ma-picks",
			children: STAFF_PICKS.map((pick) => {
				const book = getBook(pick.bookId);
				if (!book) return null;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "ma-pickrow",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/book/$bookId",
						params: { bookId: book.id },
						className: "ma-pickrow__cover",
						"aria-label": book.title,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookCover, { book })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "ma-pick__who",
							children: [pick.bookseller, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: pick.role })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/book/$bookId",
							params: { bookId: book.id },
							children: book.title
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "ma-pickrow__by",
							children: [
								book.author,
								" · ",
								formatPrice(book.price)
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "ma-pickrow__note",
							children: pick.note
						})
					] })]
				}, `${pick.bookId}-${pick.bookseller}`);
			})
		})
	})] });
}
//#endregion
export { StaffPicksPage as component };
