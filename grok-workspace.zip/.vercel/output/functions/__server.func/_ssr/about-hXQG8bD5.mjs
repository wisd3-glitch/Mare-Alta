import { C as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as BOOKSELLERS } from "./basket-store-Bul83CGW.mjs";
import { i as PageHead } from "./router-uVvk7cxV.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/about-hXQG8bD5.js
var import_jsx_runtime = require_jsx_runtime();
function AboutPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
			pt: "A casa",
			en: "About the shop",
			deck: "Why a small shop by the river still bothers to choose, and who is choosing.",
			image: "https://images.unsplash.com/photo-1521587760476-6c12a4b040da?auto=format&fit=crop&w=2000&q=80",
			imageAlt: "A grand reading room with long tables"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "ma-section",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "ma-wrap",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "row g-5 align-items-start",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "col-lg-7",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "ma-kicker ma-kicker--left",
								children: "A história"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "ma-h2 ma-h2--left",
								children: "The shop’s story"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "ma-prose",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Maré Alta opened because the evenings along the Tagus were already full of people with nowhere to take a book except home. The name means high tide: the river, and the way the room fills after six." }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "We sell new books in Portuguese and English. We are not trying to be a giant catalogue. If you want every prize-winner from the last decade, the big shops up the hill will oblige. If you want the book someone here finished on the ferry, this is the counter." }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Locals come for a shop with opinions. Expats and remote workers come for English that is not only airport paperbacks, and for a club that learns their name. Visitors come because the street is easy to miss and the book they leave with is not." })
								]
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "col-lg-5",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
							className: "ma-figure",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: "https://images.unsplash.com/photo-1585208798174-6cedd86e019a?auto=format&fit=crop&w=1400&q=80",
								alt: "Lisbon rooftops and the river in late light"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("figcaption", { children: "A short walk from Cais do Sodré. The hill does the rest." })]
						})
					})]
				})
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "ma-section ma-section--tint",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "ma-wrap",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "ma-kicker",
						children: "As pessoas"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "ma-h2",
						children: "The booksellers"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "row g-4",
						children: BOOKSELLERS.map((person) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "col-md-4",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
								className: "ma-person",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "ma-person__mark",
										"aria-hidden": "true",
										children: person.initials
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", { children: person.name }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "ma-event__pt",
										children: person.role
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: person.bio })
								]
							})
						}, person.name))
					})
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "ma-section",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "ma-wrap ma-why",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "ma-kicker ma-kicker--left",
						children: "Porquê"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "ma-h2 ma-h2--left",
						children: "Why the shop exists"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "So that a Thursday in Lisbon still has a room where someone reads for fifteen minutes and then stops, and the questions are better than the introduction. The website should sound like that room." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/events",
						className: "ma-btn ma-btn--ink",
						children: "Come on a Thursday"
					})
				]
			})
		})
	] });
}
//#endregion
export { AboutPage as component };
