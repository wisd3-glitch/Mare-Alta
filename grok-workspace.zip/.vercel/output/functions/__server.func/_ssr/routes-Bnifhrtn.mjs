import { i as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, Y as require_react, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as EVENTS, c as STAFF_PICKS, d as getBook, o as HOURS, r as BOOK_OF_WEEK_ID, t as BOOKS } from "./basket-store-Bul83CGW.mjs";
import { d as Gift, f as Feather, p as BookOpen, r as Users, u as Languages } from "../_libs/lucide-react.mjs";
import { t as BookCover } from "./BookCover-J8GnyYfz.mjs";
import { t as BookCard } from "./BookCard-DYILD5xy.mjs";
import { a as Pagination, i as A11y, n as SwiperSlide, r as Autoplay, t as Swiper } from "../_libs/swiper.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-Bnifhrtn.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var SLIDES = [
	{
		id: "week",
		image: "https://images.unsplash.com/photo-1524995997946-a1c2e315a42f?auto=format&fit=crop&w=2000&q=80",
		imageAlt: "Warm wooden shelves filled with books",
		kicker: "Livro da semana · Book of the week",
		title: "The Salt Ledger",
		deck: "Books chosen by people who have read them.",
		cta: "See why we chose it",
		showCover: true
	},
	{
		id: "thursday",
		image: "https://images.unsplash.com/photo-1481627834876-b7833e8f5570?auto=format&fit=crop&w=2000&q=80",
		imageAlt: "A long library aisle in the evening",
		kicker: "Quinta à noite · Thursday night",
		title: "The room fills up.",
		deck: "Two local authors. Fifteen minutes each. Then the questions. Free, upstairs.",
		cta: "See the evening",
		showCover: false
	},
	{
		id: "picks",
		image: "https://images.unsplash.com/photo-1555881400-74d7acaacd8b?auto=format&fit=crop&w=2000&q=80",
		imageAlt: "A yellow tram on a Lisbon street",
		kicker: "Escolhas da casa · Staff picks",
		title: "Six books we will not stop recommending.",
		deck: "Notes from the people behind the till, not from a catalogue.",
		cta: "Read the notes",
		showCover: false
	}
];
function Hero() {
	const [ready, setReady] = (0, import_react.useState)(false);
	const [reduceMotion, setReduceMotion] = (0, import_react.useState)(false);
	const week = getBook(BOOK_OF_WEEK_ID);
	(0, import_react.useEffect)(() => {
		setReady(true);
		setReduceMotion(window.matchMedia("(prefers-reduced-motion: reduce)").matches);
	}, []);
	const first = SLIDES[0];
	if (!ready) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "ma-hero",
		"aria-label": "Featured",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
			className: "ma-hero__slide",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					className: "ma-hero__img",
					src: first.image,
					alt: first.imageAlt
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "ma-hero__shade" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SlideCopy, {
					slide: first,
					week
				})
			]
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "ma-hero",
		"aria-label": "Featured",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Swiper, {
			modules: [
				Autoplay,
				Pagination,
				A11y
			],
			slidesPerView: 1,
			loop: true,
			speed: reduceMotion ? 0 : 700,
			autoplay: reduceMotion ? false : {
				delay: 6500,
				disableOnInteraction: false,
				pauseOnMouseEnter: true
			},
			pagination: { clickable: true },
			a11y: { enabled: true },
			children: SLIDES.map((slide) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SwiperSlide, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "ma-hero__slide",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						className: "ma-hero__img",
						src: slide.image,
						alt: slide.imageAlt
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "ma-hero__shade" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SlideCopy, {
						slide,
						week
					})
				]
			}) }, slide.id))
		})
	});
}
function SlideCopy({ slide, week }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "ma-wrap ma-hero__copy",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: slide.showCover ? "ma-hero__split" : "ma-hero__center",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "ma-hero__kicker",
					children: slide.kicker
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "ma-hero__title",
					children: slide.title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "ma-hero__deck",
					children: slide.deck
				}),
				slide.id === "week" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/book/$bookId",
					params: { bookId: BOOK_OF_WEEK_ID },
					className: "ma-btn ma-btn--ink",
					children: slide.cta
				}) : null,
				slide.id === "thursday" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/events",
					className: "ma-btn ma-btn--ink",
					children: slide.cta
				}) : null,
				slide.id === "picks" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/staff-picks",
					className: "ma-btn ma-btn--ink",
					children: slide.cta
				}) : null
			] }), slide.showCover && week ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "ma-hero__book",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookCover, { book: week })
			}) : null]
		})
	});
}
var HOME_IDS = [
	"the-salt-ledger",
	"night-ferry",
	"houses-of-the-tagus",
	"tide-tables",
	"the-small-lighthouse",
	"a-year-in-alfama"
];
function Home() {
	const picks = HOME_IDS.map((id) => getBook(id)).filter((book) => Boolean(book));
	const notes = STAFF_PICKS.slice(0, 3);
	const next = EVENTS.slice(0, 2);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hero, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "ma-services",
			"aria-label": "What the shop is for",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "ma-wrap ma-services__row",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Service, {
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Languages, { size: 26 }),
						label: "Portuguese & English"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Service, {
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookOpen, { size: 26 }),
						label: "Thursday readings"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Service, {
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { size: 26 }),
						label: "A book club that fills"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Service, {
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Gift, { size: 26 }),
						label: "Gift wrap, if you ask"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Service, {
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Feather, { size: 26 }),
						label: "Near Cais do Sodré"
					})
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "ma-section",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "ma-wrap",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "ma-kicker",
						children: "O que ler a seguir"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "ma-h2",
						children: "Discover your next book"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "ma-sub",
						children: "Not the whole warehouse. The ones we have actually finished, and would put in your hands."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "ma-home-grid",
						children: picks.map((book) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookCard, { book }, book.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "ma-center",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/shop",
							search: {
								q: "",
								cat: "all",
								sort: "featured"
							},
							className: "ma-btn ma-btn--ink",
							children: "The whole table"
						})
					})
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "ma-section ma-section--tint",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "ma-wrap",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "ma-kicker",
						children: "Escolhas da casa"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "ma-h2",
						children: "Staff picks"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "ma-sub",
						children: "Three of the six. The booksellers wrote these, not a blurb mill."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "row g-4",
						children: notes.map((pick) => {
							const book = getBook(pick.bookId);
							if (!book) return null;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "col-md-4",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
									className: "ma-pick",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookCard, { book }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "ma-pick__note",
											children: pick.note
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "ma-pick__who",
											children: [pick.bookseller, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: pick.role })]
										})
									]
								})
							}, pick.bookId);
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "ma-center",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/staff-picks",
							className: "ma-btn ma-btn--ghost",
							children: "All six notes"
						})
					})
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "ma-section",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "ma-wrap",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "ma-kicker",
						children: "A agenda"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "ma-h2",
						children: "Next two evenings"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "row g-4",
						children: next.map((event) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "col-md-6",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
								className: "ma-event",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "ma-event__date",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: event.day }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: event.month })]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "ma-event__pt",
										children: event.pt
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", { children: event.title }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "ma-event__when",
										children: [
											event.dateLabel,
											" · ",
											event.time,
											" · ",
											event.meta
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: event.detail })
								] })]
							})
						}, event.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "ma-center",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/events",
							className: "ma-btn ma-btn--ghost",
							children: "The full calendar"
						})
					})
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "ma-azulejo",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "ma-wrap ma-azulejo__grid",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "ma-kicker ma-kicker--light",
						children: "O correio"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "ma-h2 ma-h2--light",
						children: "One email a week."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "New arrivals, events, and one book we cannot stop recommending." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NewsletterForm, {})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "ma-hours-card",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "ma-kicker",
							children: "Horário"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "ma-h2 ma-h2--left",
							children: "Opening hours"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "ma-hours",
							children: HOURS.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: row.days }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: row.hours })] }, row.days))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "ma-fine",
							children: "Monday to Saturday, 10:00 to 20:00. Sunday, 12:00 to 18:00."
						})
					]
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "ma-sr",
			children: [BOOKS.length, " books in the catalogue."]
		})
	] });
}
function Service({ icon, label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "ma-service",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			"aria-hidden": "true",
			children: icon
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: label })]
	});
}
function NewsletterForm() {
	const [done, setDone] = (0, import_react.useState)(false);
	function onSubmit(event) {
		event.preventDefault();
		setDone(true);
	}
	if (done) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "ma-form__done",
		role: "status",
		children: "Noted on this page. One email a week — new arrivals, events, and one book we cannot stop recommending."
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		className: "ma-form",
		onSubmit,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
				htmlFor: "home-email",
				children: "Email"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "ma-form__row",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					id: "home-email",
					name: "email",
					type: "email",
					required: true,
					autoComplete: "email",
					placeholder: "you@example.com"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "submit",
					className: "ma-btn ma-btn--paper",
					children: "Join the list"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "ma-fine",
				children: "Concept shop: this stays in your browser. We do not store the address."
			})
		]
	});
}
//#endregion
export { Home as component };
