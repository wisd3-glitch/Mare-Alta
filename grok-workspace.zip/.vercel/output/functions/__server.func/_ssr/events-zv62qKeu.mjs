import { i as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, Y as require_react, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as EVENTS, d as getBook } from "./basket-store-Bul83CGW.mjs";
import { i as PageHead } from "./router-uVvk7cxV.mjs";
import { t as BookCover } from "./BookCover-J8GnyYfz.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/events-zv62qKeu.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function EventsPage() {
	const clubBook = getBook("the-salt-ledger");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
		pt: "A agenda",
		en: "Events and book club",
		deck: "Readings, Saturday story hour, and a Sunday club that fills the upstairs room.",
		image: "https://images.unsplash.com/photo-1495446815901-a7297e633e8d?auto=format&fit=crop&w=2000&q=80",
		imageAlt: "A stack of books on a wooden table"
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "ma-section",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "ma-wrap",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "row g-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "col-lg-7",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "ma-kicker ma-kicker--left",
							children: "O calendário"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "ma-h2 ma-h2--left",
							children: "What’s on"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "ma-calendar",
							children: EVENTS.map((event) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "ma-event__date",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: event.day }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: event.month })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "ma-event__pt",
									children: event.pt
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", { children: event.title }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "ma-event__when",
									children: [
										event.dateLabel,
										" · ",
										event.time,
										" · ",
										event.meta
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: event.detail })
							] })] }, event.id))
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "col-lg-5",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "ma-club",
						id: "club",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "ma-kicker ma-kicker--left",
								children: "O clube"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "ma-h2 ma-h2--left",
								children: "This month’s book"
							}),
							clubBook ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "ma-club__book",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/book/$bookId",
									params: { bookId: clubBook.id },
									"aria-label": clubBook.title,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookCover, { book: clubBook })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: "/book/$bookId",
										params: { bookId: clubBook.id },
										children: clubBook.title
									}) }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: clubBook.author }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "ma-event__when",
										children: "Next date · Sunday 6 December, 17:00"
									})
								] })]
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "First Sunday book club. Bring one page you want to read aloud. The kettle goes on at 16:40. About fourteen people, then we stop the list." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(JoinForm, {})
						]
					})
				})]
			})
		})
	})] });
}
function JoinForm() {
	const [done, setDone] = (0, import_react.useState)(false);
	function onSubmit(event) {
		event.preventDefault();
		setDone(true);
	}
	if (done) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "ma-form__done",
		role: "status",
		children: "You’re on the list for this page. We’ll keep a chair until the room is full."
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		className: "ma-form ma-form--stack",
		onSubmit,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
				htmlFor: "club-name",
				children: "Name"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				id: "club-name",
				name: "name",
				required: true,
				autoComplete: "name"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
				htmlFor: "club-email",
				children: "Email"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				id: "club-email",
				name: "email",
				type: "email",
				required: true,
				autoComplete: "email"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
				htmlFor: "club-page",
				children: "The page you might read aloud"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
				id: "club-page",
				name: "page",
				rows: 3,
				placeholder: "Optional. A page number is enough."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "submit",
				className: "ma-btn ma-btn--accent",
				children: "Join the club"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "ma-fine",
				children: "Concept shop: nothing is emailed. The note stays in this browser."
			})
		]
	});
}
//#endregion
export { EventsPage as component };
