import { C as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { l as categoryLabel } from "./basket-store-Bul83CGW.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/BookCover-J8GnyYfz.js
var import_jsx_runtime = require_jsx_runtime();
function BookCover({ book }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: `ma-cover ma-cover--${book.layout}`,
		"data-tone": book.tone,
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "ma-cover__cat",
				children: categoryLabel(book.category)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "ma-cover__title",
				children: book.title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "ma-cover__author",
				children: book.author
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "ma-cover__wave" })
		]
	});
}
//#endregion
export { BookCover as t };
