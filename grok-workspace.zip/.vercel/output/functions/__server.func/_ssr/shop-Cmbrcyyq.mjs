import { i as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, Y as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as CATEGORIES, t as BOOKS } from "./basket-store-Bul83CGW.mjs";
import { i as PageHead, r as Route$2 } from "./router-uVvk7cxV.mjs";
import { t as BookCard } from "./BookCard-DYILD5xy.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/shop-Cmbrcyyq.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function sortBooks(books, sort) {
	const next = [...books];
	if (sort === "title") next.sort((a, b) => a.title.localeCompare(b.title));
	else if (sort === "price-asc") next.sort((a, b) => a.price - b.price);
	else if (sort === "price-desc") next.sort((a, b) => b.price - a.price);
	return next;
}
function IsotopeShop({ cat, query, sort, onCat, onSort }) {
	const gridRef = (0, import_react.useRef)(null);
	const isoRef = (0, import_react.useRef)(null);
	const filterRef = (0, import_react.useRef)(() => true);
	const [ready, setReady] = (0, import_react.useState)(false);
	const ordered = sortBooks(BOOKS, sort);
	const visibleCount = ordered.filter((book) => bookMatches(book, cat, query)).length;
	filterRef.current = (el) => {
		const node = el;
		const catOk = cat === "all" || node.getAttribute("data-cat") === cat;
		const blob = node.getAttribute("data-search") ?? "";
		const q = query.trim().toLowerCase();
		return catOk && (!q || blob.includes(q));
	};
	(0, import_react.useEffect)(() => {
		let dead = false;
		let iso = null;
		const grid = gridRef.current;
		(async () => {
			const { default: Isotope } = await import("../_libs/isotope-layout+[...].mjs").then((n) => /* @__PURE__ */ __toESM(n.t()));
			if (dead || !grid) return;
			const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
			iso = new Isotope(grid, {
				itemSelector: ".book-item",
				layoutMode: "fitRows",
				percentPosition: true,
				transitionDuration: reduce ? 0 : "0.45s"
			});
			isoRef.current = iso;
			iso.arrange({ filter: (el) => filterRef.current(el) });
			setReady(true);
		})();
		return () => {
			dead = true;
			iso?.destroy();
			isoRef.current = null;
		};
	}, [sort]);
	(0, import_react.useEffect)(() => {
		const iso = isoRef.current;
		if (!iso) return;
		iso.reloadItems();
		iso.arrange({ filter: (el) => filterRef.current(el) });
	}, [
		cat,
		query,
		sort,
		ready
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "ma-shopbar",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "ma-filters",
				role: "tablist",
				"aria-label": "Filter the shelves",
				children: CATEGORIES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					role: "tab",
					"aria-selected": cat === item.id,
					className: cat === item.id ? "is-active" : void 0,
					onClick: () => onCat(item.id),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "ma-filters__pt",
						children: item.pt
					}), item.en]
				}, item.id))
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "ma-sort",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Sort" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					value: sort,
					onChange: (event) => onSort(event.target.value),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "featured",
							children: "As on the table"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "title",
							children: "Title"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "price-asc",
							children: "Price, low to high"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "price-desc",
							children: "Price, high to low"
						})
					]
				})]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "ma-count",
			"aria-live": "polite",
			children: [visibleCount === 0 ? "Nothing on that shelf." : `${visibleCount} ${visibleCount === 1 ? "book" : "books"}`, query.trim() ? ` for “${query.trim()}”` : ""]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "ma-grid",
			ref: gridRef,
			children: ordered.map((book) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "book-item",
				"data-cat": book.category,
				"data-search": `${book.title} ${book.author} ${book.description}`.toLowerCase(),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookCard, {
					book,
					showDescription: true,
					showButton: true
				})
			}, book.id))
		}),
		visibleCount === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "ma-empty",
			children: "Try another shelf, or a shorter word. The river is still there."
		}) : null
	] });
}
function bookMatches(book, cat, query) {
	const catOk = cat === "all" || book.category === cat;
	const blob = `${book.title} ${book.author} ${book.description}`.toLowerCase();
	const q = query.trim().toLowerCase();
	return catOk && (!q || blob.includes(q));
}
function ShopPage() {
	const { q, cat, sort } = Route$2.useSearch();
	const navigate = Route$2.useNavigate();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
		pt: "A livraria",
		en: "The shop",
		deck: "Fiction, non-fiction, Portuguese authors, children and poetry. Prices in euros, invented for this concept.",
		image: "https://images.unsplash.com/photo-1507842217343-583bb7270b66?auto=format&fit=crop&w=2000&q=80",
		imageAlt: "Bookshelves in a quiet library"
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "ma-section",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "ma-wrap",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IsotopeShop, {
				cat,
				query: q,
				sort,
				onCat: (next) => {
					navigate({ search: {
						q,
						cat: next,
						sort
					} });
				},
				onSort: (next) => {
					navigate({ search: {
						q,
						cat,
						sort: next
					} });
				}
			})
		})
	})] });
}
//#endregion
export { ShopPage as component };
