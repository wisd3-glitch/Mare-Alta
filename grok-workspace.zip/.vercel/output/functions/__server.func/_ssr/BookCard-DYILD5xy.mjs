import { i as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, Y as require_react, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { f as useBasket, u as formatPrice } from "./basket-store-Bul83CGW.mjs";
import { t as BookCover } from "./BookCover-J8GnyYfz.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/BookCard-DYILD5xy.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function BookCard({ book, showDescription = false, showButton = false }) {
	const add = useBasket((s) => s.add);
	const [added, setAdded] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "ma-card",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/book/$bookId",
				params: { bookId: book.id },
				className: "ma-card__cover",
				"aria-label": book.title,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookCover, { book })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "ma-card__title",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/book/$bookId",
					params: { bookId: book.id },
					children: book.title
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "ma-card__author",
				children: book.author
			}),
			showDescription ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "ma-card__desc",
				children: book.description
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "ma-card__price",
				children: formatPrice(book.price)
			}),
			showButton ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "ma-btn ma-btn--accent ma-btn--block",
				onClick: () => {
					add(book.id);
					setAdded(true);
					window.setTimeout(() => setAdded(false), 1400);
				},
				children: added ? "Added" : "Add to basket"
			}) : null
		]
	});
}
//#endregion
export { BookCard as t };
