//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-seGj6Jie.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/about",
			"/contact",
			"/events",
			"/shop",
			"/staff-picks",
			"/book/$bookId"
		],
		preloads: [
			"/assets/index-CMjYwcmI.js",
			"/assets/rolldown-runtime-CbXtAM7H.js",
			"/assets/basket-store-B4zpMkA0.js",
			"/assets/preload-helper-BgUZZe0x.js",
			"/assets/useNavigate-DGuIDARH.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CMjYwcmI.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		css: ["/assets/routes-CSXwHl-h.css"],
		preloads: [
			"/assets/routes-EV6_q6uU.js",
			"/assets/BookCover-Dkjkn1eW.js",
			"/assets/BookCard-Dm93rH7_.js"
		]
	},
	"/about": {
		filePath: "/workspace/src/routes/about.tsx",
		children: void 0,
		preloads: ["/assets/about-DUp3aP1g.js"]
	},
	"/contact": {
		filePath: "/workspace/src/routes/contact.tsx",
		children: void 0,
		preloads: ["/assets/contact-Dy8hDkAO.js"]
	},
	"/events": {
		filePath: "/workspace/src/routes/events.tsx",
		children: void 0,
		preloads: ["/assets/events-B5iXvehY.js", "/assets/BookCover-Dkjkn1eW.js"]
	},
	"/shop": {
		filePath: "/workspace/src/routes/shop.tsx",
		children: void 0,
		preloads: ["/assets/shop-Dy5BfNE5.js", "/assets/BookCard-Dm93rH7_.js"]
	},
	"/staff-picks": {
		filePath: "/workspace/src/routes/staff-picks.tsx",
		children: void 0,
		preloads: ["/assets/staff-picks-CZ8-8yAx.js", "/assets/BookCover-Dkjkn1eW.js"]
	},
	"/book/$bookId": {
		filePath: "/workspace/src/routes/book.$bookId.tsx",
		children: void 0,
		preloads: [
			"/assets/book._bookId-Cl9PoWuQ.js",
			"/assets/BookCover-Dkjkn1eW.js",
			"/assets/BookCard-Dm93rH7_.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
